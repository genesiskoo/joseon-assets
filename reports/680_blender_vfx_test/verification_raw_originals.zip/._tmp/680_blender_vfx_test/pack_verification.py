"""#680 final byte-exact verification log archive. Run only after root confirms full suite completion."""
from pathlib import Path
import argparse,hashlib,json,re,zipfile,sys
sys.stdout.reconfigure(encoding='utf-8')
root=Path.cwd().resolve(); local=root/'._tmp/680_blender_vfx_test'
report=Path('C:/workspace/joseon-assets/reports/680_blender_vfx_test')
ap=argparse.ArgumentParser(); ap.add_argument('--plan-only',action='store_true'); ap.add_argument('--full-suite-exit',type=int); ap.add_argument('--targeted-retest',action='append',default=[]); ap.add_argument('--targeted-exit',type=int); args=ap.parse_args()
selected={}
for p in local.iterdir():
    if p.is_file() and p.suffix in ['.log','.json','.txt']:
        selected[p.resolve()]=p
for pattern in ['680_hybrid*.log','680_existing_element_unit.log']:
    for p in (root/'._tmp').glob(pattern):
        if p.is_file(): selected[p.resolve()]=p
selected[Path(__file__).resolve()]=Path(__file__).resolve()
phase_paths={}
for p in list(selected):
    if p.suffix!='.log': continue
    raw=p.read_bytes().decode('utf-8-sig',errors='replace')
    for found in re.findall(r'^E2E_PHASE_RAW\s+(.+)$',raw,re.M):
        phase=Path(found.strip()).resolve()
        assert phase.is_relative_to(root/'tmp/e2e_raw'),('phase outside this worktree raw archive',phase)
        assert phase.is_dir(),('missing referenced phase originals',phase)
        phase_paths[phase]={'mentioned_by':str(p.relative_to(root))}
for phase,evidence in phase_paths.items():
    for p in phase.rglob('*'):
        if p.is_file(): selected[p.resolve()]=p
    meta=json.loads((phase/'phase.json').read_text(encoding='utf-8-sig'))
    raw=phase/'godot.raw.log'; assert raw.exists()
    recorded=meta['godot_log']; assert raw.stat().st_size==recorded['bytes'] and hashlib.sha256(raw.read_bytes()).hexdigest()==recorded['sha256'],('original Godot phase mismatch',phase)
    evidence.update({'phase_json':str((phase/'phase.json').relative_to(root)),'original_godot_sha256':recorded['sha256'],'phase_exit_code':meta['exit_code'],'phase_arg':meta['launch']['phase_arg']})
full=(local/'full_suite.raw.log').read_bytes(); fulltext=full.decode('utf-8-sig',errors='replace')
rows=[]
for p in sorted(selected,key=str):
    data=p.read_bytes(); rows.append({'entry':p.relative_to(root).as_posix(),'source_path':str(p),'uncompressed_bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
plan={'card':680,'selected_files':len(rows),'uncompressed_bytes':sum(e['uncompressed_bytes'] for e in rows),'referenced_phase_directories':len(phase_paths),'full_suite_current_bytes':len(full),'full_suite_success_marker_present':bool(re.search(r'^전부 PASS\s*$',fulltext,re.M))}
if args.plan_only:
    print(json.dumps(plan,ensure_ascii=False)); raise SystemExit()
assert args.full_suite_exit in [0,1],'Root completion/exit confirmation required; never archive an unfinished full suite as final.'
related=[]
if args.full_suite_exit==0:
    assert plan['full_suite_success_marker_present'],'Completed full suite success marker missing.'
else:
    assert re.search(r'^실패\s+\d+\s*$',fulltext,re.M),'Completed failure summary missing; a running suite is not a completed failure.'
    assert args.targeted_retest and args.targeted_exit==0,'Preserve failed full suite separately and require explicit root-confirmed related retest exit0.'
for name in args.targeted_retest:
    path=(root/name).resolve(); assert path.is_relative_to(local) and path.exists()
    data=path.read_bytes(); text=data.decode('utf-8-sig',errors='replace')
    assert 'PASS' in text and not re.search(r'\bfails=[1-9]\d*|^\s*✗|SCRIPT ERROR|Parse Error',text,re.M),('Related retest not a clean pass',path)
    row={'raw_entry':path.relative_to(root).as_posix(),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'exit_code_confirmed_by_root':args.targeted_exit,'original_pass_lines':[s for s in text.splitlines() if 'PASS' in s]}
    verdict=path.with_name(path.name.replace('.raw.log','.verdict.json'))
    if verdict.exists():
        vdata=verdict.read_bytes(); result=json.loads(vdata.decode('utf-8-sig'))
        if result==[]:
            proof={'violations':result}
        else:
            assert isinstance(result,dict) and result.get('godot_exit_code')==0 and result.get('unit_verdict_exit_code')==0 and result.get('verdict')=='PASS',('unit_verdict not a completed pass',verdict,result)
            assert result['raw_sha256']==hashlib.sha256(data).hexdigest(),('verdict raw byte mismatch',verdict)
            for pkey,skey in [('raw_path','raw_sha256'),('engine_log_path','engine_log_sha256'),('previous_fixed_raw_path','previous_fixed_raw_sha256')]:
                if pkey in result:
                    evidence=(root/result[pkey]).resolve(); assert evidence.is_relative_to(local) and evidence in selected
                    assert hashlib.sha256(evidence.read_bytes()).hexdigest()==result[skey],('verdict evidence mismatch',pkey,evidence)
            for pkey,skey in [('test_script_path','test_script_sha256'),('error_allow_path','error_allow_sha256')]:
                evidence=Path(result[pkey]).resolve(); assert evidence.is_relative_to(root)
                assert hashlib.sha256(evidence.read_bytes()).hexdigest()==result[skey],('focused test contract changed',pkey,evidence)
            assert hashlib.sha256((root/'tools/unit_verdict.py').read_bytes()).hexdigest()==result['unit_verdict_script_sha256']
            proof={'godot_exit_code':result['godot_exit_code'],'unit_verdict_exit_code':result['unit_verdict_exit_code'],'verdict':result['verdict'],'actual_raw_and_engine_sha256_verified':True}
        row['unit_verdict']={'entry':verdict.relative_to(root).as_posix(),'sha256':hashlib.sha256(vdata).hexdigest(),**proof}
    related.append(row)
capture_manifest_path=report/'video_manifest.json'
capture_manifest=json.loads(capture_manifest_path.read_text(encoding='utf-8'))
capture_audit=capture_manifest['source_after_commit_verification']
assert capture_manifest['phase_after']=='after04' and capture_manifest['every_absolute_combat_field_exact']
assert capture_audit['all_after_sources_match_final_commit'] and capture_audit['captured_resource_files']==893 and capture_audit['raw_byte_exact_files']==873 and len(capture_audit['existing_crlf_metadata_exceptions'])==20
assert (local/'commit_source_audit.raw.log').resolve() in selected
capture_archive=report/'capture_raw_originals.zip'
capture_link={'final_after_phase':capture_manifest['phase_after'],'game_commit':capture_manifest['source_after_commit'],'source_after_commit_verification':{'all_after_sources_match_final_commit':capture_audit['all_after_sources_match_final_commit'],'captured_resource_files':capture_audit['captured_resource_files'],'raw_byte_exact_files':capture_audit['raw_byte_exact_files'],'existing_baseline_crlf_metadata_only':len(capture_audit['existing_crlf_metadata_exceptions'])},'commit_audit_raw_entry':'._tmp/680_blender_vfx_test/commit_source_audit.raw.log','video_manifest_file':capture_manifest_path.name,'video_manifest_sha256':hashlib.sha256(capture_manifest_path.read_bytes()).hexdigest(),'capture_originals_archive':capture_archive.name,'capture_originals_archive_sha256':hashlib.sha256(capture_archive.read_bytes()).hexdigest(),'before_checks':capture_manifest['before_checks'],'after_checks':capture_manifest['after_checks'],'every_absolute_combat_field_exact':True}
before={p:(p.stat().st_size,p.stat().st_mtime_ns) for p in selected}
report.mkdir(parents=True,exist_ok=True); archive=report/'verification_raw_originals.zip'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for entry in rows:
        source=Path(entry['source_path']); data=source.read_bytes(); assert len(data)==entry['uncompressed_bytes'] and hashlib.sha256(data).hexdigest()==entry['sha256'],'Source changed during final archive snapshot.'
        z.writestr(entry['entry'],data)
for p,stamp in before.items(): assert (p.stat().st_size,p.stat().st_mtime_ns)==stamp,('verification source still being written',p)
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    for entry in rows:
        data=z.read(entry['entry']); assert len(data)==entry['uncompressed_bytes'] and hashlib.sha256(data).hexdigest()==entry['sha256']
assert archive.stat().st_size<10_000_000
manifest={'card':680,'archive':archive.name,'bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'zip_crc_and_all_original_byte_sha256_verified':True,'capture_and_final_game_commit':capture_link,'full_suite':{'exit_code_confirmed_by_root':args.full_suite_exit,'raw_entry':'._tmp/680_blender_vfx_test/full_suite.raw.log','sha256':hashlib.sha256(full).hexdigest(),'success_marker_present':plan['full_suite_success_marker_present'],'failure_summary_original_lines':re.findall(r'^실패\s+\d+\s*$',fulltext,re.M),'unit_pass_lines':len(re.findall(r'^\s+PASS\s+test_[^ ]+\.gd',fulltext,re.M)),'unit_failure_original_lines':re.findall(r'^\s*FAIL\s+test_[^\r\n]+',fulltext,re.M),'e2e_summary_original_lines':re.findall(r'^E2E SUMMARY:.+$',fulltext,re.M)},'related_retest_separate_from_full_suite':related,'reporting_rule':'A failed original full suite remains exit1. Successful targeted test-only corrections are recorded separately; no combined result is relabelled as one full-suite exit0.','purpose':'Byte-exact unit/native probe/import/parse/failure/focused/full suite originals; console.merged.raw is decoded wrapper output, godot.raw.log retains original engine bytes. Failed and fixed fixtures are both preserved. Capture originals are separate capture_raw_originals.zip.','phase_directories':{str(p.relative_to(root)):v for p,v in phase_paths.items()},'entries':rows}
(report/'verification_manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
all_files=[p for p in report.rglob('*') if p.is_file()]; total=sum(p.stat().st_size for p in all_files)
assert total<50_000_000 and all(p.stat().st_size<10_000_000 for p in all_files),('report budget exceeded',total)
print(json.dumps({'archive':str(archive),'archive_bytes':archive.stat().st_size,'entry_files':len(rows),'phase_dirs':len(phase_paths),'report_total_bytes':total,'original_full_suite_exit':args.full_suite_exit,'unit_pass_lines':manifest['full_suite']['unit_pass_lines'],'unit_failures':manifest['full_suite']['unit_failure_original_lines'],'related_retest':related,'e2e_summary_lines':manifest['full_suite']['e2e_summary_original_lines']},ensure_ascii=False))
