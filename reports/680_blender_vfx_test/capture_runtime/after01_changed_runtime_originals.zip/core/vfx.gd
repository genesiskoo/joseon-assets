extends Node
## Vfx — 이펙트 골격 (design/vfx.md §1·§3, 보드 #45). 큐 이름 하나로 부른다:
##   Vfx.play("hit", pos)                          단발
##   Vfx.play("slash_arc", pos, {"dir": v})        방향·크기·색·수명은 opts
##   Vfx.attach("portal_idle", node, offset)       상시(루프) — 부모가 사라지면 같이 사라진다
## 큐 → 종류(particles 프리셋 | ring | pillar | screen | sheet 빌보드 | loop). `assets/vfx/<cue>/<cue>_sheet.png` + `_meta.json`이 있으면
## 시트가 프리셋을 대체한다(코드 수정 0, 초상 시트와 같은 규약). 파일이 없으면 프리셋 파티클이 "무언가"를 보여 준다.
## 왜 오토로드+큐인가: 배우·소품이 절차 생성이라 씬에 파티클을 심을 자리가 없고, 자산은 뒤에 큐 단위로 온다 — 오디오 골격(core/audio.gd)과 같은 이유,
##   같은 훅 자리·같은 프레임(임팩트 프레임)에서 Audio.play 옆에 Vfx.play를 부른다. 헤드리스(더미 렌더러)에서도 노드는 만들어지므로 e2e는 recent()로 "불렸는가"만 본다.
## 여기 = 큐 표·재생(play/attach/play_ui/play_area)·상한·풀·시트 로더·박자. 메시·재질·셰이더·글자 판·범위 판을 **짓는** 코드는 core/vfx_meshes.gd(VfxMeshes, #418) —
##   구조 회오리 모양은 core/vfx_whirl.gd(#630). 여기서는 만들어진 루트를 붙이고 예산·번쩍을 관리한다. 바깥 이름(make_glyph·make_area·glyph_ramp·상수)은 되넘겨 그대로다.

## 시트 폴더 — 테스트가 픽스처(res://tests/fixtures/vfx/)로 바꿔 끼운다.
var sheet_dir: String = "res://assets/vfx/"
## 층 하나에 루프 attach가 40건(횃불 2×20)이라 64면 e2e가 앞을 잃는다 (실측) → 256. 512 (#628): 명중 한 번이 이력 대여섯 줄(hit · 별 · 피 · 조각 · 먹 · 자국)이 됐다.
const HISTORY_MAX := 512
## 동시 단발 노드 상한 — 넘치면 새 것을 생략한다(이력엔 남김). 상시 루프는 따로 센다. 큐 표 big(큰 순간 — 보스 포효·寶 착지, #282)은 이 상한에 안 막힌다(_is_big).
const MAX_LIVE := 24
## 구조 회오리 (#630)는 자기 가족 안에서만 오래된 루트를 통째로 걷는다. 다른 전투/피/루프를 밀어내지 않는다.
const MAX_WHIRL := 6
const WhirlFx := preload("res://core/vfx_whirl.gd")
const MAX_ELEMENTS := 8
const MAX_ELEMENT_TRAILS := 16
const ElementFx := preload("res://core/vfx_elements.gd")
const BlenderHybridFx := preload("res://core/vfx_blender_hybrid.gd")
## #680 opt-in comparison only. Actor combat/movement and the adopted default remain unchanged.
var blender_test_enabled := false
## 단발 칸 (#395 피 · #628 조각) — 공용 · 피(큐 표 gore) · 조각(큐 표 bits)은 상한을 따로 센다. 큰 모양(타격 시트·고리·도장)이 장식 조각에 굶지 않게.
## (구조 회오리·원소 구조(#630·#632)는 칸이 아니라 제 가족 상한 — 위 MAX_WHIRL·MAX_ELEMENTS.)
enum Lane { MAIN, GORE, BITS }
## 조각(bits) 전용 단발 상한 (#628 V2) — 타격마다 오는 불꽃 조각·먹 방울(한 대에 둘). 회오리가 무리 열을 치면 조각만 20 — 공용 24에 두면 그 순간
## 뒤엣것들의 타격 시트(큰 모양)가 빠진다(§1 ⑩ 「상한이 절정을 먹음」). 피(#395)와 같은 까닭으로 나누고, 밀어내기(우선순위)는 V11(#636).
const MAX_BITS := 32
## 피(gore 큐, 큐 표 "gore": true) 전용 단발 상한 — 공용 24와 따로 센다(#395, game_feel_v2 §11.7 「재질 단발(새) … 24 —
## 공용 24와 따로」). 값은 공용과 같은 24를 그대로 — 흑랑 처치 실측(살아 있는 공용 단발 최대 21~24)에서도 한 판에 피가
## 이 상한에 닿을 만큼 몰린 적은 없다(한 킬이 만드는 피는 최대 2 + 두 동강 뿜기 4 = 6). 공용 상한(24)을 늘리는 대신 이
## 쪽만 나눈 이유는 §11.7이 "공용 상한 24 → 40" 안을 "피가 몰리면 타격 불꽃이 다시 굶는다"며 기각했기 때문 — 같은
## 논리로 장식성(먼지·섬광 등)을 오래된 순으로 밀어내는 안도 기각: 장식성도 큰 순간의 신호(드랍 광선·封·道 글자)라
## 밀어내면 그쪽이 조용히 빠지는 같은 문제를 다른 큐로 옮길 뿐이다. 밀어내기 없이 그냥 나누는 쪽이 규칙이 간단하고
## §11.7과 정확히 맞는다.
const MAX_GORE := 24
## 평소 피(#359, game_feel_v2 §11.7 — 큐 표 "gore_low": true = 칼 타격마다 오는 재질 피 · 도호 피격 피)는 피 칸의 아래 칸:
## 피 칸이 차면 평소 피는 생략(이력엔 남는다)하고, 뿜기·막타 피(gore_low 없음)는 가장 오래된 평소 피를 끄고 들어간다 —
## 회오리로 여럿을 쳐 평소 피가 칸을 채워도 막타의 피 튐·뿜음은 안 빠진다(#395가 피를 공용과 가른 것과 같은 까닭을 한 칸 더).
## 루프 상한 — 횃불마다 불씨+불꽃 시트 2개 × 층당 15~30개라 넉넉히 (실측: 64면 던전 먼지가 밀려 안 붙음)
const MAX_LOOPS := 128
## 링 프리셋이 퍼져 닿는 반지름 = 이 값 × scale (판 2×2 · 셰이더 반지름 0.2 → 이 값). opts.radius가 이것으로 scale을 되짚는다 (#385).
const RING_REACH := 0.95
## 빛 번쩍 (#615 V1, vfx_rework §2 ① 「힘 = 빛」) — 터지는 순간 바닥·몸을 밝히는 짧은 점광. 디아2는 투사체 43%가 색 빛을 낸다(§1.1).
## 풀 = OmniLight3D LIGHT_MAX개를 돌려 쓴다(그림자 없음 · 클러스터 조명이라 이 정도는 싸다) · 넘치면 가장 오래 켠 것을 넘겨받는다(지금 터지는 빛이 이긴다).
const LIGHT_MAX := 8
## 점광 높이의 바닥 — 바닥 이펙트(고리·도장, y ≈ 0)는 이만큼 띄워 바닥 웅덩이 + 몸 옆면을 같이 밝힌다. 몸 높이에서 터지는 건 그 자리 그대로.
const LIGHT_LIFT := 0.8
## opts.radius(판정 반지름)를 받은 큐(회오리 등) — 빛 반경이 적어도 판정 반지름 × 이만큼은 닿는다.
const LIGHT_RADIUS_REACH := 1.4
## 바닥 먹 자국 (#628 V2 — vfx_rework §5 「평타 명중 — 여운」, 큐 표 kind mark): 맞은 몸 발밑 작은 먹 판 — 가장자리부터 마르며 MARK_DRY초에 사라진다.
## 상한 = 단발과 따로(KillFx 핏자국 32와도 따로) — 넘치면 가장 오래된 것부터 MARK_RETIRE초에 마저 마른다(뚝 사라지면 눈에 띈다).
const MARK_CAP := 24
const MARK_DRY := 2.0
const MARK_RETIRE := 0.2
## 바닥 위 높이 — 핏자국(KillFx.STAIN_Y 0.025) 바로 밑 · 그리는 순서도 맨 아래(VfxMeshes.MARK_PRIORITY).
const MARK_Y := 0.02
## 먹이 바닥에 닿아 번지는 시간(크기 MARK_SPREAD_FROM → 1).
const MARK_SPREAD := 0.12
const MARK_SPREAD_FROM := 0.6
## 칼이 빠지는 쪽으로 이만큼(유닛) 앞에 — 먹은 맞은 몸 너머로 튄다.
const MARK_AHEAD := 0.3
## 튄 쪽으로 늘이는 몫 (KillFx 착지 자국 stretch와 같은 뜻).
const MARK_STRETCH := 1.25

## 색 팔레트 (vfx.md §3)
const INK := Color(0.08, 0.07, 0.09)
const MANA := Color(0.35, 0.6, 1.0)
const FIRE := Color(1.0, 0.82, 0.58)
const BLOOD := Color(0.8, 0.15, 0.1)
const GOLD := Color(1.0, 0.85, 0.35)
const DUST := Color(0.55, 0.5, 0.42)
## 플레이스홀더 전용 — 먹색 입자는 어두운 바닥에서 안 보여(실측) 시트가 올 때까지 밝은 강철색으로 대신한다
const STEEL := Color(0.92, 0.9, 0.8)
const SMOKE := Color(0.32, 0.29, 0.33)
## 역병 김·고름 (D-090 역병 재질 결, 고름독 #331) — 검푸른 김. 먹색 입자는 어두운 바닥에서 안 보여 한 눈금 밝은 청록으로.
const PLAGUE := Color(0.4, 0.64, 0.56)
## 피 = 검붉은 먹 (D-080, game_feel_v2 §10). 방울은 조금 밝게 — 어두운 바닥에서 튀는 게 보이게. 피 표현을 끄면 부르는 쪽이 INK를 넘긴다(KillFx.splat_color).
const GORE := Color(0.35, 0.03, 0.03)
const GORE_DROP := Color(0.5, 0.05, 0.04)
## 재질 피 (#359, game_feel_v2 §11.3 — D-090 재질 4, 색표 셈 = actors/blood_fx.gd): 역병 = 검푸른 탁한 피(튐 · 방울 — 방울이 굵고 무겁다, 불 약점을 읽힌다) ·
## 쇠 = 불티 + 쇳가루(피가 아니다 — 피 끄기와 무관) · 넋 = 청록 먹 연기(혼불 청록 SOUL_SMOKE를 흐리게 α 0.55).
const PLAGUE_GORE := Color(0.12, 0.22, 0.24)
const PLAGUE_GORE_DROP := Color(0.20, 0.32, 0.33)
const IRON_SPARK := Color(1.0, 0.72, 0.30)
const IRON_DUST := Color(0.22, 0.21, 0.23)
const SOUL_HURT := Color(0.50, 0.85, 0.75, 0.55)
## 금니(金泥) — 사경에 쓰는 금가루 먹. 보상의 색(레벨업 道·寶·完, vfx.md §8.1·D-085). 글자 전용 사다리·기존 틴트의 기준색.
const GOLD_LEAF := Color(1.0, 0.72, 0.28)
## 금니의 밝은 끝 — 흰 먹 시트(바닥 먹 파문)를 금빛으로 물들일 때. 시안 R_GOLD 사다리의 밝은 쪽.
const GOLD_LEAF_LIGHT := Color(1.0, 0.84, 0.52)
## 흰 먹 — 보스·지역 글씨(封·怒·黑狼窟, D-085)
const WHITE_INK := Color(0.95, 0.94, 0.9)
## 속성 표식 색 (elements_v2 §3.2 표) — 도사 부적 꼬리·터짐 (E3 #203)
const TALISMAN_FIRE := Color(1.0, 0.55, 0.25)
const TALISMAN_COLD := Color(0.75, 0.9, 1.0)
## 재 · 박살 · 흩어짐 (#472, game_feel_v2 §10.1) — 불씨(주황, 스스로 빛나는 입자) · 재 가루(잿빛 — 먹색은 어두운 바닥에서 안 보여 한 눈금 밝게) ·
## 서리 김 · 얼음 조각 · 넋 연기(청록 — game_feel_v2 §11.3 넋 재질) · 넋의 먹 한 줌(검청 — 먹색 그대로면 안 보인다).
const EMBER := Color(1.0, 0.5, 0.18)
const ASH_GRAY := Color(0.42, 0.4, 0.38)
const FROST := Color(0.82, 0.92, 1.0)
const ICE := Color(0.7, 0.86, 1.0)
const SOUL_SMOKE := Color(0.5, 0.85, 0.75)
const SOUL_INK := Color(0.24, 0.33, 0.33)
## 살 = 검자주 먹 (monsters_v2 §17.4 「손에 검자주 먹 김」 · vfx.md §8.3 「살이 낌 = 검자주 먹 연기」, #357)
const SAL := Color(0.55, 0.14, 0.38)
const SAL_LIGHT := Color(0.85, 0.35, 0.62)
## 타격 먹 (#628 V2): 먹 방울 = 먹색 그대로면 어두운 바닥·몸 앞에서 안 보여(PLAGUE·SOUL_INK와 같은 사정) 한 눈금 밝은 검보라 ·
## 바닥 먹 자국 = 먹 그대로(바닥에 눕는 먹은 바닥보다 어두워야 읽힌다 — 핏자국 STAIN_COLOR와 같은 이치), 알파 = 처음 짙기.
const INK_DROP := Color(0.2, 0.18, 0.24)
const INK_MARK := Color(0.06, 0.05, 0.07, 0.82)
## 피격 섬광 테의 물리 색 = 따뜻한 흰빛 (#628 V2 — vfx_rework §2 ⑦ 「물리 = 흰빛」, 테 기본 색 VfxMeshes.RIM_COLOR). 속성 색은 hit_rim이 원소 빛 색(_element_color)에서 고른다.
const RIM_WHITE := VfxMeshes.RIM_COLOR

## 큐 표 (design/vfx.md §2) — preset = 파일 없을 때 모양. ground = 바닥에 눕힘. life = 초(프리셋 기본값 덮어씀). screen = 화면 오버레이 종류.
## jitter = 크기 흔들림(±비율) — 수천 번 오는 먼지만. 사다리 꼭대기(치명·Rare 착지)는 넣지 않는다 (game_feel_v2 §6.1). flip_random = 시트 좌우 무작위 뒤집기(같은 까닭, 방향 뒤집기 대신 — 먼지, #217).
## ramp = 농도 색띠 이름(시트·쿼드 입자 opt-in, #198), also_ramp = 곁들이 입자만의 색띠. 없으면 기존 color 곱.
## (#628) bits = 조각 칸(MAX_BITS, 공용 24와 따로) · kind "mark" = 바닥 먹 자국(_spawn_mark) · shake = 잡음 흔들림 칸 이름(world/camera_shake.gd LADDER — 부르면 화면이 흔들린다).
const CUES := {
	# 전투 (#46)
	# 빛 (#615 V1 — vfx_rework §2 ④ 밝기 사다리): blend "add" = 빛(가산·안개 끔) · hdr = 심 밝기(평타 ≈2.6 · 스킬 ≈3 · 치명·불 터짐 ≈4 — 시트 획은 반투명이라 1.0을 넘는 건 심뿐) ·
	# light = [세기, 반경, 수명] 빛 번쩍(+ light_color). 키가 없으면 먹(섞기·안개·1.0) — 연기·먼지·피·텔레그래프는 그대로 둔다(§2 ⑤).
	"sword_trail": {"preset": "none", "color": Color(0.95, 0.93, 0.85, 0.8), "tip_color": Color(0.35, 0.6, 1.0, 0.9), "hdr": 2.4},   # 배우 검광: 먹 mix·안개 + 좁은 날 hdr·add·안개 밖(#629). 여기선 이력·색만. tip_color = 기술의 도력 청 칼끝(#59)
	"hit": {"preset": "spark", "color": STEEL, "scale": 1.0, "blend": "add", "hdr": 2.6, "light": [2.0, 3.0, 0.2]},
	"hit_crit": {"preset": "spark", "color": GOLD_LEAF_LIGHT, "scale": 1.5, "sheet": "hit", "blend": "add", "hdr": 4.0, "light": [3.6, 4.0, 0.3], "light_color": GOLD_LEAF},   # sheet = 다른 큐의 시트를 빌려 쓴다(색·크기만 다름) · 치명 = 금니(§2 ⑦ — 전: 붉은 주황)
	"crit_flash": {"preset": "none", "color": GOLD, "screen": "vignette", "screen_life": 0.12, "screen_strength": 0.3},   # 치명 화면 금 비네트 (game_feel_v2 §2 ⑧). 피격(0.55)보다 옅게 — 치명은 자주 와서 세면 눈이 지친다(실측 캡처: 화면 전체가 금빛)
	"crit_ring": {"preset": "ring", "color": GOLD, "scale": 1.2, "life": 0.22, "ground": true, "blend": "add", "hdr": 3.0},   # 치명 발밑 짧은 링 (§2)
	# 타격 한 방 세 겹 (#628 V2 — vfx_rework §4.2·§5 「평타 명중」): Enemy.receive_attack가 hit/hit_crit(+ #216 hit_spark 별 · #359 재질 피) 위에 한 겹 더 부른다(opts.dir = 칼이 빠지는 쪽).
	# bits = 조각 칸(MAX_BITS — 공용 24와 따로) · 불꽃 조각 = 빛(가산·HDR, 입자 spark_streak) · 먹 방울 = 먹(섞기·1.0) · 자국 = kind mark(바닥, 2초에 마름 — 상한 MARK_CAP 따로).
	# 먹 방울·자국은 피가 아니다 — 피 끄기(D-080)와 무관하게 그대로. 시트(#216 hit_spark)는 사다리 꼭대기만 · 이 조각은 모든 명중.
	"hit_sparks": {"preset": "spark_streak", "color": FIRE, "scale": 1.0, "blend": "add", "hdr": 1.8, "bits": true},   # hdr ×1.8 (#628 고침 — ×3은 포개져 공이 됐다)
	"hit_sparks_crit": {"preset": "spark_streak_crit", "color": GOLD_LEAF_LIGHT, "scale": 1.0, "blend": "add", "hdr": 2.2, "bits": true},   # 치명 = 금니 · 더 길게 · 더 멀리(사다리 꼭대기라 jitter 없음)
	"hit_ink": {"preset": "ink_drop", "color": INK_DROP, "scale": 1.0, "bits": true},
	"hit_mark": {"preset": "none", "kind": "mark", "color": INK_MARK, "scale": 0.65, "life": 2.0, "ground": true, "jitter": 0.15},   # scale = 판 한 변(유닛) — 웅덩이 ≈ 판의 40%
	"whiff": {"preset": "dust", "color": DUST, "scale": 0.6, "jitter": 0.15, "sheet": "dust_impact", "flip_random": true},   # 먼지 시트 빌림 (#216 · #217)
	"slash_arc": {"preset": "ring", "color": STEEL, "scale": 1.6, "life": 0.25, "blend": "add", "hdr": 3.0, "light": [2.6, 3.8, 0.26]},
	"dash_trail": {"preset": "streak", "color": STEEL, "scale": 0.45, "life": 0.3, "hdr": 3.0},   # opts.to = 대시 끝점 · 띠는 늘 가산(빛)
	"whirl_ring": {"preset": "ring", "color": STEEL, "scale": 2.5, "life": 0.35, "ground": true, "blend": "add", "hdr": 2.6, "light": [3.2, 4.0, 0.42]},   # 크기는 부르는 쪽이 opts.radius(= 판정 반지름)로 (#385)
	"dash_dust": {"preset": "dust", "color": DUST, "scale": 1.1, "life": 0.45, "jitter": 0.15, "sheet": "dust_impact", "flip_random": true},   # 돌진이 멈춘 자리의 흙먼지 (#82 — 궤적만 있으면 "지나갔다"가 안 남는다) · 먼지 시트 빌림 (#217)
	# 도술 (#248, skills_v2 §5.2) — 새 시트 없이 흰 먹 파문(ink_ripple 시트) 빌림. 축지 = 떠난 자리·나타난 자리 먹 번짐 + 먹 연기 한 줌 · 방패 = 켜질 때 발밑 청 먹 파문
	"blink_out": {"preset": "ring", "sheet": "ink_ripple", "color": WHITE_INK, "scale": 0.55, "life": 0.35, "ground": true, "grow": 0.4, "fade": true, "also": "smoke", "also_color": SMOKE},
	"blink_in": {"preset": "ring", "sheet": "ink_ripple", "color": WHITE_INK, "scale": 0.7, "life": 0.45, "ground": true, "grow": 0.3, "fade": true, "also": "smoke", "also_color": SMOKE},
	"shield_on": {"preset": "ring", "sheet": "ink_ripple", "color": MANA, "scale": 0.8, "life": 0.5, "ground": true, "grow": 0.4, "fade": true, "blend": "add", "hdr": 1.6},
	# 스킬 타격 범위 (#385, vfx.md §9) — kind area: 판정 영역(HitArea 사전) 그대로 바닥에(play_area). edge = 경계 안쪽 붓 획 폭(유닛) ·
	# 세기 = 예고/도장의 획·먹물 · shade = 획 안쪽 먹색 그늘 · hold/fade = 도장 머묾(= 히트스톱 0.07)·마름(초). 흰 먹(D-075·D-085), 붉은 번짐 없음.
	"skill_area": {"preset": "none", "kind": "area", "color": WHITE_INK, "edge": 0.1, "edge_preview": 0.34, "fill_preview": 0.05,
			"edge_stamp": 0.9, "fill_stamp": 0.3, "shade": 0.3, "hold": 0.07, "fade": 0.28},
	# 적·보스 (#47)
	"enemy_windup": {"preset": "ring", "color": Color(1.0, 0.25, 0.15), "scale": 1.0, "life": 0.6, "ground": true, "hold": true},
	# 평소 피 = 재질 피 (#359 B1, game_feel_v2 §11.2·§11.3) — 칼 명중마다 흰 hit 섬광 곁에 하나(옛 옅은 살구빛 스파크 자리 — 한 대당 노드 수 그대로).
	# 종별 큐(<id>_hurt)가 없으면 재질 큐로: 피 enemy_hurt · 역병 enemy_hurt_plague(방울이 굵고 무겁다) · 쇠 enemy_hurt_iron(불티 + 쇳가루 한 노드) · 넋 enemy_hurt_soul(청록 연기 작게).
	# 크기·색·쪽은 부르는 쪽(EnemyDeath.hit_blood — 물리 비중 · 재질 · 칼이 빠져나간 쪽)이 opts로. gore = 피 칸(공용과 따로) · gore_low = 피 칸의 아래 칸(MAX_GORE 주석).
	"enemy_hurt": {"preset": "blood_small", "color": GORE, "scale": 1.0, "gore": true, "gore_low": true},
	"enemy_hurt_plague": {"preset": "blood_heavy", "color": PLAGUE_GORE, "scale": 1.0, "gore": true, "gore_low": true},
	"enemy_hurt_iron": {"preset": "iron", "color": Color.WHITE, "scale": 1.0, "gore": true, "gore_low": true},   # 흰 색 = 프리셋 mix(불티 · 쇳가루)가 그대로
	"enemy_hurt_soul": {"preset": "smoke", "color": SOUL_HURT, "scale": 0.5, "gore": true, "gore_low": true},
	"enemy_die": {"preset": "smoke", "color": SMOKE, "scale": 1.0},
	"enemy_dash": {"preset": "dust", "color": DUST, "scale": 0.8, "sheet": "dust_impact", "flip_random": true},   # 먼지 시트 빌림 (#217)
	# 도호 피격 (#362 → #359 B4, §11.5 판정 8): 붉은 비네트는 그대로(player_hurt — 화면만) · 밝은 빨강 스파크(BLOOD — 먹 팔레트에서 혼자 튀었다) 대신
	# 검붉은 먹 작은 피 player_blood(물리 몫이 있을 때만 — 크기 = 받은 물리 비중, PlayerCombat._hurt_blood). 바닥 자국·흘림 없음.
	"player_hurt": {"preset": "none", "color": BLOOD, "scale": 0.8, "screen": "vignette", "screen_life": 0.18},
	"player_blood": {"preset": "blood_small", "color": GORE, "scale": 1.0, "gore": true, "gore_low": true},
	"player_die": {"preset": "smoke", "color": SMOKE, "scale": 1.5},
	"talisman_shot": {"preset": "spark", "color": GOLD, "scale": 0.5},
	"talisman_trail": {"preset": "embers", "color": GOLD, "scale": 0.45, "loop": true},   # 투사체에 attach — 날아가는 꼬리
	"talisman_paper": {"preset": "none", "color": Color.WHITE, "scale": 0.6, "loop": true},   # 투사체 본체 = 도는 부적 종이 시트(있을 때만)
	"talisman_hit": {"preset": "ring", "color": BLOOD, "scale": 0.8, "life": 0.2, "sheet": "hit"},
	# 나찰녀 살 구슬 (monsters_v2 §17.4 · 투사체 모양 sal — actors/projectile.gd LOOKS, #357) — 새 시트 없이 프리셋만:
	# 쏘기 선딜·쏘는 순간 손에 검자주 먹 김 · 날아가는 꼬리 · 명중 터짐. sal_burst = 공방 살 구름 시트(#219, vfx.md §7)가 assets/vfx/sal_burst/에 오면 코드 0으로 시트
	"sal_charge": {"preset": "smoke", "color": SAL, "scale": 0.45},
	"sal_orb_trail": {"preset": "embers", "color": SAL_LIGHT, "scale": 0.5, "loop": true},
	"sal_burst": {"preset": "smoke", "color": SAL, "scale": 1.1, "also": "spark", "also_color": SAL_LIGHT, "ramp": "sal", "also_ramp": "sal"},
	# 도호의 도사 부적 (D-081 §5.1 · E3 #203, elements_v2 §7.3) — 새 시트 없이 프리셋만. 속성 색 = §3.2 표식 색(불 주황 · 한기 서리 흰청).
	# talisman_<속성>_trail = 날아가는 꼬리(부적에 attach) · _hit = 한 적에 닿음(불 스파크 + 연기) · _burst = 자리에서 터짐(바닥 링 = 반경 + 스파크)
	"talisman_throw": {"preset": "spark", "color": GOLD, "scale": 0.4, "blend": "add", "hdr": 2.6},   # 부적이 손을 떠나는 순간
	# 벽력부 기본 큐 (#632): 실제 접촉이 fizzle 연기로 떨어지지 않는다.
	"talisman_lightning_trail": {"preset": "embers", "color": GOLD_LEAF_LIGHT, "scale": 0.5, "loop": true, "blend": "add", "hdr": 3.2},
	"talisman_lightning_hit": {"preset": "spark", "color": GOLD_LEAF_LIGHT, "scale": 1.2, "blend": "add", "hdr": 4.0},
	"talisman_lightning_burst": {"preset": "spark", "color": GOLD_LEAF_LIGHT, "scale": 1.2, "blend": "add", "hdr": 4.0},
	"talisman_fire_trail": {"preset": "embers", "color": TALISMAN_FIRE, "scale": 0.5, "loop": true, "blend": "add", "hdr": 3.2, "ramp": "fire"},
	"talisman_cold_trail": {"preset": "embers", "color": TALISMAN_COLD, "scale": 0.5, "loop": true, "blend": "add", "hdr": 2.6, "ramp": "cold"},
	"talisman_fire_hit": {"preset": "spark", "color": TALISMAN_FIRE, "scale": 1.4, "also": "smoke", "also_color": SMOKE, "blend": "add", "hdr": 4.0, "light": [4.0, 5.0, 0.5], "ramp": "fire"},
	"talisman_fire_burst": {"preset": "ring", "color": TALISMAN_FIRE, "scale": 1.5, "life": 0.45, "ground": true, "also": "spark", "also_color": Color(1.0, 0.85, 0.55),
			"blend": "add", "hdr": 3.4, "also_blend": "add", "also_hdr": 4.0, "light": [4.5, 5.5, 0.6], "ramp": "fire", "also_ramp": "fire"},   # #476 — 화염부도 빙결부처럼 터진다
	"talisman_cold_burst": {"preset": "ring", "color": TALISMAN_COLD, "scale": 1.5, "life": 0.45, "ground": true, "also": "spark", "also_color": Color(0.9, 0.97, 1.0),
			"blend": "add", "hdr": 3.0, "also_blend": "add", "also_hdr": 3.2, "light": [3.6, 5.0, 0.5], "light_color": Color(0.45, 0.7, 1.0), "ramp": "cold", "also_ramp": "cold"},
	"talisman_fizzle": {"preset": "smoke", "color": SMOKE, "scale": 0.5},   # 아무도 안 맞고 사거리 끝·벽(radius 0 = 벽력부, EA 2차 — 화염부·빙결부는 radius>0이라 늘 burst로 끝난다)
	# 포효 (D-085, #282, vfx.md §8.13): 붉은 링·붉은 화면 번쩍 대신 — 바닥 먹 파문 두 겹(검은 먹 고리 + 흰 테, 안쪽 겹이 0.12초 뒤에 따라 퍼진다) + 머리 위 흰 먹 怒(0.3초에 휘갈김). 시안 after_roar3.
	# 한 겹 = 흰 먹 시트(ink_ripple 빌림) 아래 + 그보다 ×0.95 작은 검은 먹 시트 위 — 흰 띠의 안쪽을 검은 먹이 덮어 어두운 띠 + 바깥 흰 가장자리(흰 테)가 남는다(시안의 「검은 먹 고리 + 흰 테」 — 시안은
	# 선 하나라 얇고, 시트 띠는 굵어 세기를 낮췄다 · CPU 합성으로 시안 프레임에 얹어 맞춤). 이 줄 = 바깥 겹의 흰 테(지름 → 4.8 · 0.7초) · parts = 그 위 검은 먹 고리 + 안쪽 겹(지름 ×0.75 · 0.6초)의 흰 테·검은 먹.
	# 부르는 곳 = 보스 **발**(+0.1 — 바닥 시트가 제 높이를 더한다, Boss.roar_fx) · 怒 = 몸 꼭대기 + 1.0 (부르는 쪽이 opts.glyph_y 로 — 흑랑 1.74 → 발 위 2.75 = 시안(머리 1.6 + 1.15), 키 큰 보스는 같이 오른다 ·
	# 아래 glyph_y 2.65 는 값을 안 줄 때의 흑랑 높이) · 화면 흔들림 = 부르는 쪽의 cam.kick(그 길 그대로 — 붉은 번쩍만 뺐다) + 잡음 흔들림 보스 칸(shake, #628 — 겹·怒는 안 흔든다, 한 번).
	# 구미호·장산범·불가살이의 페이즈 포효도 이 줄을 쓴다. opts.radius = 바깥 겹의 바깥 반지름(불가살이 포효 반경) · opts.no_glyph = 怒 없이(반복 공격 포효에 한자를 안 쓴다, vfx.md §8.1 ③).
	# big = 큰 순간 — 겹 전부(바깥 흰 테·검은 먹·안쪽 둘)가 단발 상한(MAX_LIVE)에 안 막히고 함께 뜬다(_is_big · 怒만 남은 반쪽 포효를 막는다).
	"boss_roar": {"big": true, "preset": "ring", "sheet": "ink_ripple", "color": Color(WHITE_INK, 0.25), "scale": 1.6, "life": 0.7, "sheet_life": 0.7, "ground": true, "grow": 0.34, "fade": true,
			"parts": [
				{"cue": "ink_ripple", "mul": 0.95, "y": 0.01, "life": 0.7, "color": Color(INK, 0.6)},
				{"cue": "ink_ripple", "delay": 0.12, "mul": 0.75, "life": 0.6, "color": Color(WHITE_INK, 0.18)},
				{"cue": "ink_ripple", "delay": 0.12, "mul": 0.7125, "y": 0.01, "life": 0.6, "color": Color(INK, 0.42)},
			],
			"glyph": "glyph_no", "glyph_y": 2.65, "shake": "boss"},
	"boss_summon": {"preset": "smoke", "color": SMOKE, "scale": 1.2},
	# 흑랑 처치 (D-085, #281, vfx.md §8.11): 붉은 기둥·연기 대신 — 시체 밑 바닥에 흰 먹 封(glyph_bong)을 쓴다. 몸이 먹으로 스러지는 건 Boss(0.85~1.3초).
	"boss_die": {"preset": "none", "color": WHITE_INK, "glyph": "glyph_bong"},
	# 흑랑은 제 연출 — 일반 사망 연기(Enemy._die의 <id>_die → enemy_die)를 끈다. 封이 그 자리를 쓴다.
	"boss_heukrang_die": {"preset": "none"},
	# 장산범도 제 연출(#494 — 흑랑 틀: 먹 스러짐 + 封) · 허상은 먹물 흩어짐(soul_ink · soul_scatter)이 그 자리를 쓴다.
	"boss_jangsanbeom_die": {"preset": "none"},
	# 봉인 조각 자리 파문 (#281) — 뭉친 封이 닿는 순간 흰 먹 방울 파문(ink_ripple 시트 빌림), 지름 0.6 → 2.2 · 0.6초(부를 때 opts.life).
	"seal_ripple": {"preset": "ring", "sheet": "ink_ripple", "color": WHITE_INK, "scale": 0.73, "life": 0.6, "ground": true, "grow": 0.27, "fade": true},
	# 처치 연출 2차 (#183, game_feel_v2 §10.6) — 피 튐은 hit 먹 시트를 검붉게 빌려 쓰고(없으면 방울 입자), 방울은 따로 부채꼴로
	# gore = true (#395, game_feel_v2 §11.7): 피는 공용 단발 상한(MAX_LIVE)과 따로 제 상한(MAX_GORE)을 쓴다 — 큰 순간(보스 처치 드랍·封·道
	# 글자)이 공용 칸을 채워도 피가 조용히 밀려나지 않는다. 글자(glyph)가 상한 밖인 것과 같은 까닭.
	"blood_splat": {"preset": "blood", "color": GORE, "scale": 1.0, "sheet": "hit", "gore": true},
	"blood_drops": {"preset": "blood", "color": GORE_DROP, "scale": 1.0, "gore": true},
	"body_fall": {"preset": "dust", "color": DUST, "scale": 1.0, "life": 0.5, "jitter": 0.15, "sheet": "dust_impact", "flip_random": true},   # 시체가 땅에 닿는 흙먼지 — 처치마다 와서 흔든다 · 먼지 시트 빌림 (#217 — 크기 ±15% + 좌우 무작위로 반복을 가린다)
	"blood_gush": {"preset": "spurt", "color": GORE_DROP, "scale": 1.0, "gore": true},   # 두 동강(#184) 잘린 자리에서 뿜는 피 — 0.15초마다 한 번씩 4번(0.6초), 무너지는 몸을 따라간다
	# 재 · 박살 · 흩어짐 (#472, game_feel_v2 §10.1) — 몸이 스러지는 건 셰이더(InkDissolve — 발부터 타들어 감 · 머리부터 먹으로 풀림), 여기는 곁들이 입자.
	# 시트가 오면(assets/vfx/<cue>/) 코드 수정 0으로 바뀐다(큐 규약 — 붓 불꽃 v1c = 재 후보, vfx.md §7).
	"burn_flash": {"preset": "spark", "color": TALISMAN_FIRE, "scale": 1.3, "also": "smoke", "also_color": SMOKE, "blend": "add", "hdr": 4.0, "light": [3.4, 4.5, 0.45], "ramp": "fire"},   # 불 막타 — 주황 번쩍
	"burn_embers": {"preset": "embers", "color": EMBER, "scale": 1.0, "blend": "add", "hdr": 3.2, "ramp": "fire"},   # 타들어 가는 몸에서 오르는 불씨(두 번)
	"burn_ash": {"preset": "ash", "color": ASH_GRAY, "scale": 1.0},   # 다 탄 자리에서 흩날리다 가라앉는 재 가루
	"freeze_frost": {"preset": "dust", "color": FROST, "scale": 0.9, "life": 0.5},   # 얼음빛으로 굳는 순간 서리 김
	"shatter_shards": {"preset": "shard", "color": ICE, "scale": 1.0, "light": [2.6, 3.4, 0.35], "light_color": Color(0.5, 0.75, 1.0)},   # 박살 — 얼음 조각(곧은 파편이 날아가는 쪽으로 선다)
	"shatter_dust": {"preset": "dust", "color": FROST, "scale": 1.3, "life": 0.7},   # 박살 — 얼음 가루
	"soul_scatter": {"preset": "rise", "color": SOUL_SMOKE, "scale": 1.2},   # 넋 — 풀린 몸에서 위로 오르는 청록 먹 연기(두 번)
	"soul_ink": {"preset": "smoke", "color": SOUL_INK, "scale": 0.9},   # 넋 — 막타 순간 먹 한 줌
	"ink_smoke": {"preset": "smoke", "color": SMOKE, "scale": 0.8},   # 피 끄기 — 뿜음 곁 먹 연기(두 동강·베여 쓰러짐 — D-093 「먹물·연기 버전」)
	# 공방 시트 반입 (#216 = #217·#218·#219 합침, vfx.md §7 · 원본 #214) — 흰 먹 시트 넷. 불·살은 농도 색띠(#198), 나머지는 큐 color 곱.
	# hit_spark = 섬광 별 0.25초 — 치명·기술 타격(+ 쇠 몸은 모든 타격)에서만 hit 위에 겹친다. 사다리 꼭대기만 — 보통 평타엔 없다(game_feel_v2 §6.1). 부르는 쪽이 opts.color: 치명 GOLD · 그 밖 STEEL
	"hit_spark": {"preset": "spark", "color": STEEL, "scale": 1.0},
	# dust_impact = 먼지 임팩트 0.5초, 메타 anchor [0.5, 1.0] = 프레임 아래 가장자리가 부른 자리(바닥, #217). 위 whiff·dash_dust·enemy_dash·body_fall·drop_dust가 "sheet"로 빌린다 — 좌우 무작위(flip_random)·크기 ±15%로 반복을 가린다
	"dust_impact": {"preset": "dust", "color": DUST, "scale": 1.0, "jitter": 0.15, "flip_random": true},
	# fire_burst = 화염 폭발 0.44초 — 부적술사 불 부적 명중(Projectile, scale 0.8). 화염부(#203)·불 막타(#185)는 각 카드가 이 큐를 부른다.
	# 색 = 불 색띠(#198, 검붉은 끝→주홍→흰노랑 심). 기존 명시 opts.color만 주는 호출의 틴트는 TALISMAN_FIRE 기준 그대로.
	"fire_burst": {"preset": "spark", "color": TALISMAN_FIRE, "scale": 1.0, "ramp": "fire", "blend": "add", "hdr": 3.0},
	# 살 구름 = sal_burst — 위 나찰녀 살 구슬 줄(#357)에 시트만 얹었다(assets/vfx/sal_burst/, 큐 줄은 하나)
	# 월드 (#48)
	"dungeon_dust": {"preset": "dust_float", "color": DUST, "scale": 1.0, "loop": true},
	"stairs_mist": {"preset": "mist", "color": MANA, "scale": 1.0, "loop": true},
	"pus_steam": {"preset": "mist", "color": PLAGUE, "scale": 0.4, "loop": true},   # 고름독 김 (#331) — 옹기 아가리에서 새는 검푸른 김
	"pus_break": {"preset": "smoke", "color": PLAGUE, "scale": 0.8},   # 고름독 깨짐 (#331)
	"portal_idle": {"preset": "swirl", "color": MANA, "scale": 1.0, "loop": true},
	"portal_open": {"preset": "ring", "color": MANA, "scale": 1.2, "life": 0.4, "blend": "add", "hdr": 2.6, "light": [3.0, 5.0, 0.55]},
	"portal_use": {"preset": "none", "color": MANA},   # 통과 = 먹 번짐 전환(#285, ui/ink_wipe.gd — 셸이 덮고 걷는다). 옛 청 섬광은 갈음 · 큐는 이력·시트 자리로 남긴다
	"waypoint_idle": {"preset": "embers", "color": FIRE, "scale": 1.0, "loop": true},
	"waypoint_wake": {"preset": "pillar", "color": FIRE, "scale": 1.0, "life": 1.0},
	"waypoint_use": {"preset": "none", "screen": "flash", "screen_life": 0.15, "color": FIRE},
	"drop_dust": {"preset": "dust", "color": DUST, "scale": 0.55, "life": 0.35, "jitter": 0.15, "sheet": "dust_impact", "flip_random": true},   # 전리품 착지 흙먼지 (game_feel_v2 §4.1) · 먼지 시트 빌림 (#217)
	"drop_land_magic": {"preset": "dust", "color": MANA, "scale": 0.7, "life": 0.4, "also": "ring", "jitter": 0.15},    # 파란 템 착지: 청 먼지 + 링 한 겹 (§4.2)
	"drop_land_rare": {"preset": "dust", "color": GOLD, "scale": 0.9, "life": 0.45, "also": "ring"},    # 노란 템 착지: 황 먼지 + 링 (두 겹째는 코드가 0.09초 뒤에)
	"drop_glyph_rare": {"preset": "ring", "color": GOLD, "scale": 1.5, "life": 0.6, "ground": true},    # 노란 템 발밑 문양 0.6초 (§4.2) — 유니크는 금니로 빌림
	# 유니크 착지 (I7 #263 — 있는 프리셋으로 최소): 금니 먼지 + 링, 두 겹째는 FloorItem이 0.09초 뒤에. 금 비네트·寶는 아래 drop_treasure(#282 ← #286)가 얹는다 — 이 줄은 그대로.
	"drop_land_unique": {"preset": "dust", "color": GOLD_LEAF, "scale": 1.1, "life": 0.5, "also": "ring"},
	# 유니크·봉인 조각이 앉는 순간 한 번 (D-085, #282 ← #286, vfx.md §8.13): 금 비네트 0.2초 + 금니 먹 파문(지름 0.6 → 2.2 · 0.6초) + 떨어진 자리 위 금니 寶(glyph_bo — 발 위 1.95) 획 쓰기. 시안 after_drop3.
	# 부르는 곳 = FloorItem._land — 유니크·봉인 조각(퀘스트 물건)만 · 시체·상자에서 튀어난 무리만(가방에서 버린 건 아님) · 한 무리엔 가장 늦게 앉는 보물 하나만. 붉은 낙관·가는 광선은 안 쓴다(D-085).
	# 바닥 은은한 금빛 = 물건 밑 점광(FloorItem._add_glow #85) · 상시 광선(drop_beam)이 이미 맡는다 — 새 판을 더하지 않았다.
	# big = 큰 순간 — 금니 파문이 단발 상한(MAX_LIVE)에 안 막힌다(_is_big · 글자 寶는 원래 안 막힌다 — 파문만 빠진 반쪽 착지를 막는다).
	"drop_treasure": {"big": true, "preset": "ring", "sheet": "ink_ripple", "color": Color(GOLD_LEAF_LIGHT, 0.95), "scale": 0.73, "life": 0.6, "sheet_life": 0.6, "ground": true, "grow": 0.34, "fade": true,
			"screen": "vignette", "screen_color": Color(1.0, 0.8, 0.35), "screen_life": 0.2, "screen_strength": 0.3, "glyph": "glyph_bo", "glyph_y": 1.95},
	"drop_beam": {"preset": "beam", "color": MANA, "scale": 1.0, "loop": true},   # 바닥 아이템 Magic 청 / Rare 황 / 유니크 금니 ×1.6 + 흰 심 · 높이 2.6 (#379 — attach opts.color·scale·core·height, FloorItem.beam_opts)
	"torch_embers": {"preset": "embers", "color": FIRE, "scale": 0.45, "loop": true},   # 횃불 불씨
	"torch_flame": {"preset": "none", "color": FIRE, "scale": 0.5, "loop": true},       # 횃불 불꽃 루프 시트(있으면 발광 구 대신)
	"pickup": {"preset": "spark", "color": GOLD, "scale": 0.5, "blend": "add", "hdr": 1.8},
	"pickup_coin": {"preset": "spark", "color": GOLD, "scale": 0.6, "blend": "add", "hdr": 1.8},
	# 성장·소비 (#49)
	# 레벨업 (D-085, #280): 「레벨 업!」 글자 대신 — 발밑 금니 먹 파문(ink_ripple 시트를 금니로 빌림, 커지며 옅어짐) + 옅은 금빛(also aura)
	# + 머리 위 道 획 쓰기(glyph — 발 위 4.3 = 머리 1.75 + 2.55, 시안 §8.9). 시트가 없으면 금 링(ring). 소리는 Audio(level_up) + Main(0.6초 뒤 추임새).
	"level_up": {"preset": "ring", "sheet": "ink_ripple", "color": GOLD_LEAF_LIGHT, "scale": 1.0, "life": 0.75, "ground": true, "grow": 0.34, "fade": true,
			"also": "aura", "also_color": GOLD_LEAF, "glyph": "glyph_do", "glyph_y": 4.3, "blend": "add", "hdr": 2.0, "light": [3.2, 5.5, 1.0]},
	"potion_hp": {"preset": "rise", "color": Color(0.95, 0.35, 0.3), "scale": 1.0, "blend": "add", "hdr": 1.6},
	"potion_mp": {"preset": "rise", "color": MANA, "scale": 1.0, "blend": "add", "hdr": 1.6},
	"revive": {"preset": "pillar", "color": FIRE, "scale": 1.2, "life": 1.2},
	# 창 안 2D (play_ui)
	"identify": {"preset": "none", "color": GOLD, "ui": true},
	"equip": {"preset": "none", "color": STEEL, "ui": true},
	# 먹 방울 파문 (바닥) — Wan 먹 방울 클립 6~24장(vfx.md §8.10). grow = 처음 크기 배율 → 1(ease-out), fade = 끝까지 옅어짐. 레벨업이 금니로 빌린다.
	"ink_ripple": {"preset": "ring", "color": WHITE_INK, "scale": 1.0, "life": 0.75, "ground": true, "grow": 0.34, "fade": true},
	# 한자 획 쓰기 (D-085, vfx.md §8.8~§8.10) — kind glyph = 쓰기(write초에 칸 0..N−1) → 멈춤(hold) → 가장자리부터 스러지며 먹방울로 흩어짐(out).
	# height = 판 높이(유닛) — 또는 width = 먹 폭(유닛, 칸 비율로 높이를 정한다) · delay = 쓰기 전 기다림 · rise = 방울이 오르는 빠르기(유닛/초, 음수 = 떨어짐) · glow = 옅은 번짐 · shadow = 먹 그림자. 값 = §8.9 시안.
	# 연결 = 道(레벨업, #280) · 封(흑랑 처치, #281) · 怒(보스 포효 boss_roar, #282) · 寶(유니크·봉인 조각 착지 drop_treasure, #282 ← #286) · 完·黑狼窟·封密窟(화면 고정 글씨 — play_ui_glyph, #284).
	# 화면 고정 글씨(#284): ui_height = 글자 판 높이(창 높이의 몫) · ui_at = 글자 가운데의 창 비율(없으면 한가운데) — 쓰기·멈춤·걷힘 초는 위 값 그대로(먹방울은 없다).
	"glyph_do": {"preset": "none", "kind": "glyph", "color": GOLD_LEAF, "height": 1.8, "delay": 0.12, "write": 0.55, "hold": 0.75, "out": 0.35, "rise": 0.76, "glow": 0.3, "shadow": 0.6},
	# 封 = 바닥 封 (#281, vfx.md §8.11): ground = 바닥에 눕힌 판(글자 위 = 카메라에서 먼 쪽 — 직교 카메라가 세로를 0.577로 누른다), 시체 밑·이름표 밑·핏자국 위(깊이 §8.11).
	# end gather = 흩어지지 않고 뭉친다: 멈춤 뒤 gather초에 먹 폭 gather_width로 줄며 카메라 쪽 gather_to(봉인 조각 자리)로 → 닿으면 land 큐(흰 먹 파문) +
	# 바닥 빛(land_glow 세기 · 반지름 land_glow_r, 맥박) → linger초 머묾 → out초에 옅어짐. 시트가 없으면 흰 링(ring). 값 = 시안 after_boss_v3("white_ground").
	"glyph_bong": {"preset": "ring", "kind": "glyph", "color": WHITE_INK, "life": 1.3, "ground": true, "width": 3.6,
			"delay": 0.25, "write": 0.55, "hold": 0.5, "out": 0.5, "glow": 0.0, "shadow": 0.75,
			"end": "gather", "gather": 0.35, "gather_width": 0.36, "gather_to": 0.2, "linger": 2.4, "land": "seal_ripple", "land_glow": 0.33, "land_glow_r": 0.75},
	# 怒 = 흑랑 포효 (#282): 파문이 퍼지기 시작한 지 0.02초 뒤 0.3초에 휘갈김 → 멈춤 0.55 → 흩어짐(방울은 떨어진다). 시안 after_roar3: 시작 0.04 = 파문 0.02 + 0.02.
	"glyph_no": {"preset": "none", "kind": "glyph", "color": WHITE_INK, "height": 1.6, "delay": 0.02, "write": 0.3, "hold": 0.55, "out": 0.3, "rise": -0.61, "glow": 0.0, "shadow": 0.85},
	# 寶 = 유니크·봉인 조각 착지 (#282 ← #286): 앉은 뒤 0.04초부터 0.5초에 씀(위에서 아래) → 멈춤 0.6 → 흩어짐(방울은 오른다). 시안 after_drop3.
	"glyph_bo": {"preset": "none", "kind": "glyph", "color": GOLD_LEAF, "height": 1.35, "delay": 0.04, "write": 0.5, "hold": 0.6, "out": 0.35, "rise": 0.61, "glow": 0.3, "shadow": 0.6},
	# 完 = 퀘스트 완료 (#284, 보고 순간 NpcTalk reward → Npc): 화면 한가운데 위쪽에 금니 完 한 번 — 사례 알림(머리 위 글자)·소리는 그대로, 그 위에 더한다.
	"glyph_wan": {"preset": "none", "kind": "glyph", "color": GOLD_LEAF, "height": 1.8, "write": 0.55, "hold": 0.85, "out": 0.35, "rise": 0.61, "glow": 0.3, "shadow": 0.6,
			"ui_height": 0.27, "ui_at": Vector2(0.5, 0.36)},
	# 黑狼窟 = 지역 이름 배너 (#284): 들어서고 0.3초 뒤 흰 먹 획 쓰기 → 멈춤 → 걷힘. 자리·한글 밑줄은 ui/area_title.gd(AreaTitle) — 큐 이름 = "title_" + 지역 id.
	"title_heukrang_gul": {"preset": "none", "kind": "glyph", "color": WHITE_INK, "height": 1.2, "delay": 0.3, "write": 1.05, "hold": 1.05, "out": 0.45, "rise": 0.46, "glow": 0.0, "shadow": 0.9,
			"ui_height": 0.18},
	# 封密窟 봉밀굴 제목 (#514 반입 · #284 연결 — 흑랑 굴 제목과 같은 틀·값)
	"title_bongmil_gul": {"preset": "none", "kind": "glyph", "color": WHITE_INK, "height": 1.2, "delay": 0.3, "write": 1.05, "hold": 1.05, "out": 0.45, "rise": 0.46, "glow": 0.0, "shadow": 0.9,
			"ui_height": 0.18},
}

# ---------- 한자 획 쓰기 (glyph, D-085 · #280) ----------
## 판·먹방울·그리는 순서·금빛 판 크기 = 짓는 쪽 값이라 VfxMeshes에 있다 — 여기 이름은 되넘김(바깥 API 그대로, #418).
const GLYPH_PAD := VfxMeshes.GLYPH_PAD
const GLYPH_DROPS_MAX := VfxMeshes.GLYPH_DROPS_MAX
const GLYPH_DROP_RADIUS := VfxMeshes.GLYPH_DROP_RADIUS
const GLYPH_GROUND_PRIORITY := VfxMeshes.GLYPH_GROUND_PRIORITY
const GLYPH_GLOW_TINT := VfxMeshes.GLYPH_GLOW_TINT
const AURA_SIZE := VfxMeshes.AURA_SIZE
## 흩어질 때 판이 커지는 몫 (시안 1 + 0.18q).
const GLYPH_BURST_GROW := 0.18
## 먹방울은 흩어짐(out)보다 이만큼 더 산다 (시안 t_out + 0.25).
const GLYPH_DROP_TAIL := 0.25
## 바닥 글씨(ground, #281)를 바닥에서 띄우는 높이 — 핏자국(KillFx.STAIN_Y 0.025)보다 위라 먹이 짙은 곳의 깊이가 핏자국을 막는다(§8.11 깊이).
const GLYPH_GROUND_LIFT := 0.04
## 뭉친 글씨 밑 바닥 빛 — 차오르는 시간(초) · 맥박(rad/초) (시안 soft_glow: 0.15초 · sin 9t). 색 배율은 VfxMeshes.GLYPH_GLOW_TINT.
const GLYPH_GLOW_RAMP := 0.15
const GLYPH_GLOW_PULSE := 9.0
## 금빛 판을 카메라 쪽으로 당기는 거리 — 직교 카메라라 화면 자리는 그대로, 몸에 가리지 않게.
const AURA_FRONT := 0.8
## 금빛 세기(가산) — 시안 0.28.
const AURA_STRENGTH := 0.28

## 프리셋 = 파일이 없을 때의 파티클 모양 (vfx.md §3). 값은 GPUParticles3D + ParticleProcessMaterial.
const PRESETS := {
	"spark": {"amount": 12, "life": 0.35, "explosive": 1.0, "vel": [2.5, 4.5], "spread": 180.0, "gravity": -8.0, "size": [0.08, 0.13], "grow": 0.6, "alpha": 1.0},
	"dust": {"amount": 8, "life": 0.55, "explosive": 0.9, "vel": [0.6, 1.4], "spread": 60.0, "gravity": -0.5, "size": [0.12, 0.22], "grow": 2.0, "alpha": 0.55},
	"smoke": {"amount": 8, "life": 0.9, "explosive": 0.8, "vel": [0.3, 0.8], "spread": 40.0, "gravity": 0.3, "size": [0.25, 0.4], "grow": 2.4, "alpha": 0.6},
	"rise": {"amount": 14, "life": 0.9, "explosive": 0.3, "vel": [0.8, 1.6], "spread": 15.0, "gravity": 0.0, "size": [0.08, 0.12], "grow": 0.7, "alpha": 0.9, "radius": 0.4},
	# 피 방울 (#183): 막타 방향 부채꼴(±30°)로 튀어 무겁게 떨어진다 — 바닥 아래로 가면 바닥이 가린다
	"blood": {"amount": 18, "life": 0.55, "explosive": 1.0, "vel": [2.4, 4.6], "spread": 30.0, "gravity": -14.0, "size": [0.05, 0.11], "grow": 0.55, "alpha": 1.0},
	# 피 뿜음 (#184): 좁게(±14°) 한 줄기로 솟았다 무겁게 떨어진다 — 여러 번 이어 불러 맥박처럼
	"spurt": {"amount": 10, "life": 0.45, "explosive": 0.85, "vel": [2.2, 3.8], "spread": 14.0, "gravity": -14.0, "size": [0.045, 0.09], "grow": 0.6, "alpha": 1.0},
	# 작은 피 튐 (#359 B1, game_feel_v2 §11.9 blood_small): 방울 8~10 · 수명 0.4 · 퍼짐 ±25° · 중력 14 — 막타 방울(blood)보다 작고 느리게, 칼이 빠져나간 쪽으로
	"blood_small": {"amount": 9, "life": 0.4, "explosive": 1.0, "vel": [2.0, 3.6], "spread": 25.0, "gravity": -14.0, "size": [0.04, 0.08], "grow": 0.55, "alpha": 1.0},
	# 역병 방울 (#359, §11.3): 같은 튐을 굵고 무겁게 — 크기 ×1.25 · 속도 ×0.8 · 중력 ×1.2 (프리셋을 따로 둔다: 풀이 프리셋마다라 opts로 바꾸면 돌려 쓰는 노드에 값이 남는다)
	"blood_heavy": {"amount": 9, "life": 0.4, "explosive": 1.0, "vel": [1.6, 2.88], "spread": 25.0, "gravity": -16.8, "size": [0.05, 0.1], "grow": 0.55, "alpha": 1.0},
	# 쇠 (#359, §11.3): 불티 8~12 짧게 + 쇳가루 한 줌 — 노드 하나에서 알마다 처음 색을 고른다(mix = [색 A, 색 B, A 몫] — VfxMeshes.particles). 한 대당 노드 수 그대로
	"iron": {"amount": 12, "life": 0.3, "explosive": 1.0, "vel": [2.5, 5.0], "spread": 50.0, "gravity": -9.0, "size": [0.03, 0.06], "grow": 0.5, "alpha": 1.0,
		"mix": [IRON_SPARK, IRON_DUST, 0.7]},
	# 재 가루 (#472): 몸 둘레에서 가볍게 떠올랐다 천천히 가라앉는 잿빛 조각
	"ash": {"amount": 18, "life": 1.3, "explosive": 0.5, "vel": [0.3, 1.0], "spread": 55.0, "gravity": -0.9, "size": [0.035, 0.07], "grow": 0.7, "alpha": 0.85, "radius": 0.3},
	# 얼음 조각 (#472): 몸 부피(상자)에서 사방으로 터져 무겁게 떨어지는 곧은 파편 — 둥근 판이 아니라 얇은 삼각기둥(mesh = shard, 날아가는 쪽으로 선다)
	"shard": {"amount": 30, "life": 0.95, "explosive": 1.0, "vel": [2.0, 4.8], "spread": 80.0, "gravity": -13.0, "size": [0.1, 0.22], "grow": 0.85, "alpha": 1.0,
		"box": Vector3(0.5, 1.0, 0.5), "mesh": "shard"},
	# 불꽃 조각 (#628 V2): 늘인 띠(mesh streak — 날아가는 쪽으로 선다)가 칼이 빠지는 쪽(opts.dir) 부채꼴로 튀어 조금 떨어진다. 짧게(0.22초) — 터짐 박자.
	# lift = 방향에 더하는 위쪽 몫(부르는 쪽은 수평 방향만 넘긴다 — 바닥으로 박히지 않게). size = 띠 길이(유닛), grow = 끝 길이 몫(느려지며 짧아짐).
	# 태어날 때 한 점에 포개지지 않게 (#628 고침 — 창 모드 사진: 첫 프레임에 가산 띠가 한 점에 겹쳐 빛이 수십 배로 쌓이고 번짐이 지름 1유닛 흰 공으로 퍼뜨렸다):
	# sphere = 방출 구 반지름(유닛) · explosive 0.85 = 수명 15%(≈2프레임)에 걸쳐 나온다(fract_delta가 나이를 흩는다) · fade_in = 색 사다리 처음 몫 동안 알파 0 → 1
	# (태어나는 순간이 가장 밝지 않다 — hit 시트 첫 칸과도 덜 포갠다). 세기는 큐 표 hdr(×1.8)로.
	"spark_streak": {"amount": 8, "life": 0.22, "explosive": 0.85, "vel": [3.6, 6.8], "spread": 38.0, "gravity": -6.0, "size": [0.3, 0.5], "grow": 0.35, "alpha": 1.0,
		"mesh": "streak", "lift": 0.35, "sphere": 0.1, "fade_in": 0.12},
	# 치명 = 수보다 금니 색·길이로(§5 「치명 — 금니 번쩍 + 크게」): 조금 더 많이(10) · 더 길게 · 더 멀리
	"spark_streak_crit": {"amount": 10, "life": 0.26, "explosive": 0.85, "vel": [4.2, 7.8], "spread": 44.0, "gravity": -6.0, "size": [0.42, 0.7], "grow": 0.35, "alpha": 1.0,
		"mesh": "streak", "lift": 0.4, "sphere": 0.12, "fade_in": 0.12},
	# 먹 방울 (#628 V2): 피 방울(blood)과 같은 무게로 칼이 빠지는 쪽에 몇 방울(4) — 바닥 아래로 가면 바닥이 가린다 · 한 점(빛 한가운데 먹 점)으로 안 보이게 작은 구에서
	"ink_drop": {"amount": 4, "life": 0.5, "explosive": 1.0, "vel": [2.2, 4.0], "spread": 32.0, "gravity": -14.0, "size": [0.06, 0.11], "grow": 0.6, "alpha": 1.0, "lift": 0.5, "sphere": 0.07},
	# 루프
	"dust_float": {"amount": 24, "life": 4.0, "explosive": 0.0, "vel": [0.05, 0.15], "spread": 180.0, "gravity": 0.0, "size": [0.03, 0.05], "grow": 1.0, "alpha": 0.35, "box": Vector3(6.0, 2.0, 6.0)},
	"mist": {"amount": 10, "life": 2.5, "explosive": 0.0, "vel": [0.15, 0.3], "spread": 30.0, "gravity": 0.0, "size": [0.3, 0.5], "grow": 1.8, "alpha": 0.25, "radius": 0.6},
	"embers": {"amount": 10, "life": 1.6, "explosive": 0.0, "vel": [0.4, 0.9], "spread": 25.0, "gravity": 0.4, "size": [0.05, 0.08], "grow": 0.5, "alpha": 0.9, "radius": 0.35},
	"swirl": {"amount": 16, "life": 1.8, "explosive": 0.0, "vel": [0.2, 0.4], "spread": 10.0, "gravity": 0.0, "size": [0.06, 0.09], "grow": 0.8, "alpha": 0.9, "radius": 0.55, "orbit": 0.6},
}

var history: Array[String] = []
var seq: int = 0
## 마지막 단발 play의 크기 (흔들림 포함 — 테스트·dev 진단, #113).
var last_scale: float = 1.0

var _pool: Dictionary = {}          # preset -> Array[GPUParticles3D] (쉬는 노드, Vfx 밑에 붙여 둔다 — 트리 밖이면 종료 때 누수)
var _live_whirl: Array[Node] = []   # 여러 겹을 루트 하나로 소유하는 회오리 전용 그룹 (#630)
var _last_whirl: Node3D
var _live_elements: Array[Node] = []
var _live_element_trails: Array[Node] = []
var _last_elements: Dictionary = {}
var _live_nodes: Array[Node] = []   # 살아 있는 단발 노드 — 층과 함께 사라진 것은 _prune이 걷어낸다 (카운터만 두면 트윈 콜백을 못 받아 상한에 걸림, 실측)
var _live_gore: Array[Node] = []    # 살아 있는 피(gore) 단발 — _live_nodes와 따로 센다(#395). 같은 까닭으로 _prune이 걷어낸다.
var _live_gore_low: Array[Node] = []   # 그중 평소 피(gore_low, #359) — 오래된 것이 앞. 뿜기·막타 피가 칸이 차면 여기 맨 앞을 끄고 들어간다.
var _live_bits: Array[Node] = []    # 살아 있는 조각(bits) 단발 — 불꽃 조각·먹 방울(#628). 공용·피와 따로 센다.
var _marks: Array[Node] = []        # 살아 있는 바닥 먹 자국(#628) — 만든 순서(앞 = 가장 오래됨). 마르는 중에 밀려난 것은 뺀다.
## 상한에 걸려 못 만든 단발 수 (큐 → 수, #359 — 「불렸는데 안 만들어짐」을 e2e·dev가 센다, game_feel_v2 §11 리스크 2). 이력(history)은 부른 것, 이건 빠진 것.
var capped: Dictionary = {}
## 밀려 꺼진 평소 피 수 (#359 — 뿜기·막타 피가 칸을 비우려 끈 것).
var evicted: int = 0
var _loop_nodes: Array[Node] = []
var _sheets: Dictionary = {}        # cue -> {"frames": SpriteFrames, "meta": Dictionary} / {} = 없음(확인함)
## 큐별 마지막으로 만든 시트 노드 핸들 — 이름으로 찾으면 같은 이름이 겹칠 때(먼저 만든 것이 아직 안 죽었으면 Godot가
## 뒤엣것을 "Vfx_sheet_<cue>2"로 슬쩍 바꾼다, #395 ② 실측) 흔들린다. last_sheet(cue)가 만든 순간의 핸들을 그대로 돌려준다.
var _last_sheet: Dictionary = {}    # cue -> AnimatedSprite3D (해제됐으면 last_sheet()가 null로 거른다)
# 셰이더·재질·원판 텍스처 캐시는 VfxMeshes(static)에 — 한 번만 만들어지는 건 같다 (#418)
var _screen_layer: CanvasLayer
var _screen_rects: Dictionary = {}  # kind -> ColorRect
var _ui_layer: CanvasLayer          # 창 안 2D 반짝(play_ui)
var _missing_logged: Dictionary = {}
var _rng := RandomNumberGenerator.new()   # 게임 RNG와 분리 — 이펙트 흔들림이 시드·e2e 결정성을 건드리지 않게
var _lights: Array[OmniLight3D] = []      # 빛 번쩍 풀 (#615) — Vfx 밑(트리 안, 같은 월드)에 두고 돌려 쓴다
var _light_next: int = 0                  # 풀이 차면 다음에 넘겨받을 칸(가장 오래 켠 것부터 차례로)


func _ready() -> void:
	_rng.randomize()
	process_mode = Node.PROCESS_MODE_ALWAYS
	set_process(false)   # 화면 글씨 시계(_process)는 글씨가 쓰이는 동안에만 돈다 (#284)


## 해제된 노드(층과 함께 사라짐)·큐된 노드를 걷어낸다. 형 있는 람다(n: Node)에 해제 객체가 들어가면 filter가 통째로 빈 배열을 돌려준다(실측) → 형 없는 반복.
func _prune() -> void:
	_live_whirl = _alive(_live_whirl)
	_live_elements = _alive(_live_elements)
	_live_element_trails = _alive(_live_element_trails)
	_live_nodes = _alive(_live_nodes)
	_live_gore = _alive(_live_gore)
	_live_bits = _alive(_live_bits)
	_marks = _alive(_marks)
	_loop_nodes = _alive(_loop_nodes)
	# 평소 피 명단 = 피 명단에 아직 있는 것만(다 타서 _recycle이 피 명단에서 뺀 노드 — 풀로 돌아가 다른 큐가 다시 쓸 수 있다 — 를 여기서도 걷는다).
	# 해제된 노드(층과 함께 사라짐)는 먼저 거른다 — 형 있는 배열(_live_gore)의 has에 해제 객체를 넘기면 엔진 ERROR(named_imugi 실측, #359)
	var low: Array[Node] = []
	for n in _live_gore_low:
		if is_instance_valid(n) and _live_gore.has(n):
			low.append(n)
	_live_gore_low = low


## 큐 표 줄의 단발 칸 — 피(gore) · 조각(bits) · 공용.
static func lane_of(def: Dictionary) -> int:
	if bool(def.get("gore", false)):
		return Lane.GORE
	return Lane.BITS if bool(def.get("bits", false)) else Lane.MAIN


func _lane_nodes(lane: int) -> Array[Node]:
	match lane:
		Lane.GORE:
			return _live_gore
		Lane.BITS:
			return _live_bits
	return _live_nodes


func _lane_full(lane: int) -> bool:
	var cap := MAX_GORE if lane == Lane.GORE else (MAX_BITS if lane == Lane.BITS else MAX_LIVE)
	return _lane_nodes(lane).size() >= cap


func _alive(arr: Array[Node]) -> Array[Node]:
	var out: Array[Node] = []
	for n in arr:
		if is_instance_valid(n) and n.is_inside_tree() and not n.is_queued_for_deletion():
			out.append(n)
	return out


# ---------- 공개 API ----------

## 원소 구조 단발 (#632). 기존 cue 이력을 유지하며 입체 층 전체를 별도 가족으로 소유한다.
func element_burst(cue: String, pos: Vector3, element: StringName, opts: Dictionary = {}) -> Node3D:
	_remember(cue)
	if not element in [&"fire", &"cold", &"lightning", &"sal"]:
		return null
	var radius := float(opts.get("radius", 0.65))
	if not is_finite(radius) or radius <= 0.0:
		return null
	var host: Node = opts.get("parent")
	if host == null and is_inside_tree():
		host = _root()
	if not is_instance_valid(host) or not host.is_inside_tree() or host.is_queued_for_deletion():
		return null
	var grade: int = ElementFx.grade_for(float(opts.get("power", 1.0)), float(opts.get("look_scale", 1.0)))
	var node: Node3D = ElementFx.make_burst(element, radius, grade)
	if node == null:
		return null
	_prune()
	if _live_elements.size() >= MAX_ELEMENTS:
		var oldest: Node = _live_elements.pop_front()
		(oldest as Node3D).visible = false
		oldest.queue_free()
	node.name = "Vfx_element_%s" % element
	host.add_child(node, true)
	node.global_position = pos
	# 접촉 몸통은 가슴 높이, 마르는 자국은 실제 바닥(y=0)이다.
	var ground := node.get_node_or_null("GroundTrace") as Node3D
	if ground != null:
		ground.global_position = Vector3(pos.x, 0.026, pos.z)
	_live_elements.append(node)
	_last_elements[element] = node
	var energy := float([1.8, 3.2, 4.6][grade])
	if element == &"sal":
		energy *= 0.3
	var light: OmniLight3D = flash_light(pos, _element_color(element), energy, maxf(1.4, radius * LIGHT_RADIUS_REACH), float([0.10, 0.14, 0.18][grade]))
	if light != null:
		var tw: Tween = light.get_meta("tw")
		tw.set_pause_mode(Tween.TWEEN_PAUSE_STOP)
		node.tree_exiting.connect(func() -> void:
			if is_instance_valid(light) and light.get_meta("tw", null) == tw:
				if tw.is_valid():
					tw.kill()
				light.light_energy = 0.0
				light.visible = false)
	if element == &"lightning":
		_screen("element_flash", GOLD_LEAF_LIGHT, 0.05, float([0.018, 0.03, 0.05][grade]))
		var rect: ColorRect = _screen_rects.get("element_flash")
		var flash_tw: Tween = rect.get_meta("element_tw")
		var rect_ref: WeakRef = weakref(rect)
		node.tree_exiting.connect(func() -> void:
			var safe_rect := rect_ref.get_ref() as ColorRect
			if safe_rect != null and safe_rect.get_meta("element_tw", null) == flash_tw:
				if flash_tw.is_valid():
					flash_tw.kill()
				safe_rect.visible = false)
	return node


## 원소 비행은 운반체 자식. 기존 루프 카운터에 한 묶음이며 원소 trail16 상한도 지킨다.
func attach_element(cue: String, parent: Node3D, element: StringName, opts: Dictionary = {}) -> Node3D:
	_remember(cue)
	if not element in [&"fire", &"cold", &"lightning", &"sal"] or not is_instance_valid(parent) or not parent.is_inside_tree() or parent.is_queued_for_deletion():
		return null
	_prune()
	if _loop_nodes.size() >= MAX_LOOPS:
		return null
	var grade: int = ElementFx.grade_for(float(opts.get("power", 1.0)), float(opts.get("look_scale", 1.0)))
	var node: Node3D = BlenderHybridFx.make_trail(element, grade) if blender_test_enabled else null
	if node == null:
		node = ElementFx.make_trail(element, grade)
	if node == null:
		return null
	if _live_element_trails.size() >= MAX_ELEMENT_TRAILS:
		var oldest: Node = _live_element_trails.pop_front()
		(oldest as Node3D).visible = false
		oldest.queue_free()
	node.name = "Vfx_" + cue
	parent.add_child(node, true)
	node.position = opts.get("offset", Vector3.ZERO)
	_loop_nodes.append(node)
	_live_element_trails.append(node)
	return node


func element_live_count() -> int:
	_prune()
	return _live_elements.size()


func element_trail_count() -> int:
	_prune()
	return _live_element_trails.size()


func last_element(element: StringName) -> Node3D:
	var node: Variant = _last_elements.get(element)
	if not is_instance_valid(node) or not node.is_inside_tree() or node.is_queued_for_deletion():
		return null
	return node as Node3D


## 원소 빛 색 (#632 원소 구조 번쩍) — 피격 섬광 테(hit_rim, #628)도 이 표를 쓴다(두 벌 두지 않는다). static = hit_rim(static)이 부른다.
static func _element_color(element: StringName) -> Color:
	match element:
		&"fire": return TALISMAN_FIRE
		&"cold": return FROST
		&"lightning": return GOLD_LEAF_LIGHT
		_: return SAL_LIGHT


## 회오리 계열 구조 시안 (#630). 판정/타격 이력은 기존 whirl_ring, 그림의 여러 겹은 한 루트로 소유한다.
## 공용/피/루프와 별도 6그룹이라 전투가 몰려도 몸통이 빠지지 않는다. 넘치면 이 가족의 오래된 루트만 통째로 걷는다.
func whirl_burst(pos: Vector3, radius: float, grade: int, role: String = "impact", variant: String = "whirl", dir: Vector3 = Vector3.FORWARD, parent: Node = null) -> Node3D:
	_remember("whirl_ring")
	if not is_finite(radius) or radius <= 0.0:
		return null
	var host := parent
	if host == null:
		if not is_inside_tree():
			return null
		host = _root()
	if not is_instance_valid(host) or not host.is_inside_tree() or host.is_queued_for_deletion():
		return null
	var rank := clampi(grade, 0, 2)
	var node: Node3D = WhirlFx.make(radius, rank, role, variant)
	if node == null:
		return null
	_prune()
	if _live_whirl.size() >= MAX_WHIRL:
		var oldest: Node = _live_whirl.pop_front()
		(oldest as Node3D).visible = false
		oldest.queue_free()
	node.name = "Vfx_whirl_ring_%s_%s" % [variant, role]
	host.add_child(node, true)
	node.global_position = pos
	var facing := Vector3(dir.x, 0.0, dir.z)
	if facing.length_squared() > 0.0001:
		node.global_rotation = Vector3(0.0, atan2(-facing.x, -facing.z), 0.0)
	_live_whirl.append(node)
	_last_whirl = node
	if role != "afterimage":
		var energy := float([1.3, 2.5, 3.8][rank])
		var life := float([0.10, 0.14, 0.18][rank])
		if variant == "storm":
			energy *= 1.2
			life *= 0.8
		var light: OmniLight3D = flash_light(pos, Color(0.86, 0.93, 1.0), energy, maxf(2.0, radius * LIGHT_RADIUS_REACH), life)
		if light != null:
			var tw: Tween = light.get_meta("tw")
			tw.set_pause_mode(Tween.TWEEN_PAUSE_STOP)
			# 풀을 다른 효과가 넘겨받았으면 그 새 번쩍은 건드리지 않는다.
			node.tree_exiting.connect(func() -> void:
				if is_instance_valid(light) and light.get_meta("tw", null) == tw:
					if tw.is_valid():
						tw.kill()
					light.light_energy = 0.0
					light.visible = false)
	return node


## 구조 회오리 전용 살아 있는 그룹 수/마지막 루트 — 시안 검증과 dev 진단.
func whirl_live_count() -> int:
	_prune()
	return _live_whirl.size()


func last_whirl() -> Node3D:
	if not is_instance_valid(_last_whirl) or not _last_whirl.is_inside_tree() or _last_whirl.is_queued_for_deletion():
		return null
	return _last_whirl


## 단발. opts = {dir: Vector3, scale: float, color: Color, life: float, parent: Node}. fallback = 종별 큐가 없을 때 쓸 공용 큐(enemy_hurt 등).
## 반환 = 실제로 뭔가 만들었는가 (이력엔 항상 남는다 — e2e).
func play(cue: String, pos: Vector3, opts: Dictionary = {}, fallback: String = "") -> bool:
	_remember(cue)
	var name := cue if CUES.has(cue) else fallback
	if name == "" or not CUES.has(name):
		_log_missing(cue)
		return false
	var def: Dictionary = CUES[name]
	var parent: Node = opts.get("parent", _root())
	if parent == null:
		return false
	# 피(gore, #395)·조각(bits, #628) 큐는 공용 단발과 따로 센다 — 아래 상한 검사·풀 담기·last_sheet 기록이 이 칸(Lane)으로 어느 배열을 쓸지 고른다.
	var lane := lane_of(def)
	# 평소 피(gore_low, #359)는 칸이 차면 빠지고, 뿜기·막타 피는 가장 오래된 평소 피를 끄고 들어간다(§11.7 — MAX_GORE 주석)
	var low := lane == Lane.GORE and bool(def.get("gore_low", false))
	if lane == Lane.GORE and not low:
		_make_gore_room()
	var color: Color = opts.get("color", def.get("color", Color.WHITE))
	var scale: float = float(opts.get("scale", def.get("scale", 1.0)))
	# 빛 (#615 V1, vfx_rework §2 ④~⑥): blend "add" = 가산 + 안개 끔(빛) · 없으면 섞기(먹·연기·피 — 세상과 같이 안개) ·
	# hdr = 심 밝기(선형 배율, 1 = 옛 그림 — 1.0을 넘는 곳만 번짐이 걸린다)
	var add := String(opts.get("blend", def.get("blend", "mix"))) == "add"
	var energy := float(opts.get("hdr", def.get("hdr", 1.0)))
	var ramp := _ramp_for(def, opts)
	# 반복 방지 (game_feel_v2 §6.1, #113): 상시 먼지는 크기를 흔든다 — 큐 표 "jitter"(±비율). 크기를 정해 부른 곳(opts.scale)은 그대로.
	if def.has("jitter") and not opts.has("scale"):
		scale *= 1.0 + _rng.randf_range(-float(def.jitter), float(def.jitter))
	last_scale = scale
	var made := false
	if def.has("screen"):
		# screen_color = 화면 오버레이만 따로 물들일 때(#282 유니크 착지: 파문은 밝은 금니 · 비네트는 짙은 금) — 없으면 큐 색.
		_screen(String(def.screen), def.get("screen_color", color), float(opts.get("screen_life", def.get("screen_life", 0.15))), float(def.get("screen_strength", 0.55)))
		made = true
	var sheet := _sheet_for(String(def.get("sheet", name)))   # "sheet" = 빌려 쓰는 시트 큐 (hit_crit → hit)
	# opts.radius = 바깥 반지름(유닛)으로 크기를 정한다 (#385) — 시트는 한 칸 = 지름(units × scale), 링 프리셋은 반지름 RING_REACH × scale.
	# 판정 반지름을 그대로 넘기면 어느 쪽이 그려지든 먹 고리가 판정 경계에 선다(전: 회오리가 scale = 반지름이라 시트 고리가 판정의 절반).
	if opts.has("radius"):
		scale = radius_scale(float(opts.radius), sheet)
		last_scale = scale
	if not sheet.is_empty():
		if String(def.get("kind", "")) == "glyph":
			made = _spawn_glyph(name, sheet, parent, pos, scale, def, opts) or made
		else:
			# sheet_life = 큐 표가 시트 재생 길이(초)를 정한다 — 부르는 쪽이 opts.life 를 주는 것과 같은 효과(주면 그쪽이 먼저, #282). 없는 큐는 시트 원래 길이 그대로.
			var sopts := opts
			if def.has("sheet_life") and not opts.has("life"):
				sopts = opts.duplicate()
				sopts["life"] = float(def.sheet_life)
			# #282의 재생 시간 복사와 #615의 빛 인자(add·energy)를 함께 전달한다 — 먹 겹·빛 재질 계약을 각각 유지.
			made = _spawn_sheet(name, sheet, parent, pos, scale, def, sopts, lane, add, energy, low) or made
	elif String(def.get("kind", "")) == "mark":
		made = _spawn_mark(parent, pos, color, scale, float(opts.get("life", def.get("life", MARK_DRY))), opts.get("dir", Vector3.ZERO)) or made
	else:
		var preset := String(def.get("preset", "none"))
		# 상한이 차면 그림만 생략(_note_capped) — 곁들이·겹·글자는 제 검사로, 빛 번쩍·흔들림은 아래에서 그대로(#615 「빛은 따로」 · #628: 전엔 여기서 돌아가 프리셋 큐는 빛까지 빠졌다)
		var drawn := preset != "none"
		if drawn:
			_prune()
			if not _is_big(def, opts) and _lane_full(lane):
				_note_capped(name)
				drawn = false
		if drawn:
			var life: float = float(opts.get("life", def.get("life", 0.0)))
			match preset:
				"ring":
					made = _spawn_ring(parent, pos, color, scale, life if life > 0.0 else 0.3, bool(def.get("ground", false)), bool(def.get("hold", false)), add, energy) or made
				"pillar":
					made = _spawn_pillar(parent, pos, color, scale, life if life > 0.0 else 1.0) or made
				"streak":
					var to: Vector3 = opts.get("to", pos + Vector3(opts.get("dir", Vector3.RIGHT)).normalized() * 2.0)
					made = _spawn_streak(parent, pos, to, color, scale, life if life > 0.0 else 0.3, energy) or made
				_:
					made = _spawn_particles(preset, parent, pos, color, scale, opts.get("dir", Vector3.ZERO), false, lane, add, energy, low, ramp) != null or made
	# 곁들이 — 시트가 있든 없든 (#280: 레벨업은 파문 시트 + 금빛 + 道). also = 같은 자리에 한 겹 더(ring·aura·입자 프리셋),
	# glyph = 위에 한자 한 글자(큐 표 glyph_y만큼 위, 같은 부모 — 도호를 따라간다). 한자도 제 큐라 이력에 따로 남는다.
	var also := String(def.get("also", ""))
	if also != "" and not _lane_full(lane):
		var also_color: Color = def.get("also_color", color)
		# 곁들이도 제 겹침·밝기(also_blend·also_hdr, #615) — 불 터짐의 불꽃은 빛, 곁 연기는 먹(기본 섞기)
		var also_add := String(def.get("also_blend", "mix")) == "add"
		var also_energy := float(def.get("also_hdr", 1.0))
		match also:
			"ring":
				_spawn_ring(parent, pos, also_color, scale, 0.5, true, false, also_add, also_energy)
			"aura":
				made = _spawn_aura(parent, pos, also_color, scale, float(def.get("aura_life", 1.4))) or made
			_:
				_spawn_particles(also, parent, pos, also_color, scale, Vector3.ZERO, false, lane, also_add, also_energy, low, _ramp_for({"ramp": def.get("also_ramp", "")}, {}))
	if def.has("parts"):
		made = _play_parts(def, pos, parent, scale, _is_big(def, opts)) or made
	# opts.no_glyph = 한자 없이 (반복하는 사건엔 글자를 안 쓴다 — 불가살이의 포효 공격, vfx.md §8.1 ③ · #282)
	# opts.glyph_y = 글자 높이를 부르는 쪽이 정한다(키 큰 보스 — Boss.roar_glyph_y) — 없으면 큐 표 값
	if def.has("glyph") and not bool(opts.get("no_glyph", false)):
		made = play(String(def.glyph), pos + Vector3(0.0, float(opts.get("glyph_y", def.get("glyph_y", 0.0))), 0.0), {"parent": parent}) or made
	# 빛 번쩍 (#615) — 상한에 걸려 그림이 생략돼도 빛은 따로 켠다(빛 풀은 단발 상한 밖 · 절정에서 빠지지 않게)
	if def.has("light"):
		_light_for(def, pos, color, opts)
	_shake_for(def, opts)
	return made


## 색띠는 opt-in. 명시 color만 주는 기존 호출(피 끄기·개별 틴트)은 그대로, opts.ramp는 color와 함께 줘도 우선.
## 빈 이름/알 수 없는 이름은 기존 틴트. glyph·area·ring은 제 재질을 쓰므로 이 선택으로 바뀌지 않는다(#198).
func _ramp_for(def: Dictionary, opts: Dictionary) -> String:
	if opts.has("color") and not opts.has("ramp"):
		return ""
	var name := String(opts.get("ramp", def.get("ramp", "")))
	return name if VfxMeshes.EFFECT_PALETTES.has(name) else ""


## 겹 (#282) — 큐 표 parts = [{cue, delay(초) · y(위로 유닛) · mul(크기 배율) · color · life}] : 같은 자리에 다른 큐를 겹쳐 부른다(포효 먹 파문 두 겹의 흰 테·안쪽 겹).
## 크기 = 이 큐가 정해진 크기(scale — opts.radius·opts.scale 로 키운 것까지) × mul 이라, 반경으로 부르면 겹도 같이 선다. delay > 0 이면 그만큼 뒤에 부른다 —
## 게임 시간(트리가 멈추면 같이 멈춤)이고, 그 사이 부모(층)가 사라졌으면 건너뛴다. 트리 밖(단위 시험)이면 기다리는 겹은 건너뛴다. 반환 = 부른 겹이 하나라도 있나.
## big = 이 큐가 큰 순간이면 겹도 함께 상한에 안 막힌다(opts.big 로 물려준다 — 겹의 큐는 먹 파문 같은 작은 큐라 제 줄엔 표식이 없다).
func _play_parts(def: Dictionary, pos: Vector3, parent: Node, scale: float, big: bool = false) -> bool:
	var made := false
	for part in def.parts:
		var cue := String(part.get("cue", ""))
		if not CUES.has(cue):
			continue
		var sub := {"parent": parent, "scale": scale * float(part.get("mul", 1.0))}
		if big:
			sub["big"] = true
		if part.has("color"):
			sub["color"] = part.color
		if part.has("life"):
			sub["life"] = float(part.life)
		var at := pos + Vector3(0.0, float(part.get("y", 0.0)), 0.0)
		var delay := float(part.get("delay", 0.0))
		if delay <= 0.0:
			made = play(cue, at, sub) or made
		elif is_inside_tree():
			get_tree().create_timer(delay, false).timeout.connect(_play_late.bind(cue, at, sub))
			made = true
	return made


## 큰 순간인가 (D-085, #282) — 큐 표 "big": true(보스 포효·寶 착지) 또는 겹이 부모에게서 받은 opts.big. 큰 순간은 단발 상한(MAX_LIVE)에 막히지 않는다:
## 겹 하나만 빠져도 그림이 깨지는 순간(怒만 남은 반쪽 포효 — #216 시트가 칸을 자주 채워 21 이상이면 0.12초 뒤 안쪽 겹이 잘렸다)이라, 글자·시전 범위 판이 상한 밖인 것과 같은 까닭이다.
## 가장 오래된 작은 이펙트를 밀어내는 길은 MAX_GORE 와 같은 논리로 기각(장식성도 큰 순간의 신호). 드문 순간이라(보스 페이즈당 한 번 · 한 무리에 寶 하나) 상한을 몇 겹 넘어도 싸고,
## 노드는 그대로 센다 — 이어 오는 작은 이펙트(타격 불꽃·먼지)가 그만큼 더 생략될 뿐 상한 규칙은 그대로다.
func _is_big(def: Dictionary, opts: Dictionary) -> bool:
	return bool(opts.get("big", def.get("big", false)))


## 기다렸다 부르는 겹 — 그 사이 부모(층·몸)가 사라졌으면 아무것도 안 한다. 부모를 Variant 로 먼저 받는다(해제된 객체를 형 있는 변수에 넣으면 그 자리에서 오류, _recycle 과 같은 이유).
func _play_late(cue: String, at: Vector3, sub: Dictionary) -> void:
	var p = sub.get("parent")
	if not is_instance_valid(p) or not (p as Node).is_inside_tree():
		return
	play(cue, at, sub)


## 상시 루프(문·서낭단·계단·던전 먼지·드랍 광선). 부모 밑에 붙여 부모와 수명을 같이한다. opts = {color, scale}. 반환 = 만든 노드(없으면 null).
func attach(cue: String, parent: Node3D, offset: Vector3 = Vector3.ZERO, opts: Dictionary = {}) -> Node3D:
	_remember(cue)
	if parent == null or not CUES.has(cue):
		_log_missing(cue)
		return null
	_prune()
	if _loop_nodes.size() >= MAX_LOOPS:
		return null
	var def: Dictionary = CUES[cue]
	var color: Color = opts.get("color", def.get("color", Color.WHITE))
	var scale: float = float(opts.get("scale", def.get("scale", 1.0)))
	var add := String(opts.get("blend", def.get("blend", "mix"))) == "add"   # 빛 (#615 — play와 같은 키)
	var energy := float(opts.get("hdr", def.get("hdr", 1.0)))
	var ramp := _ramp_for(def, opts)
	var sheet := _sheet_for(String(def.get("sheet", cue)))
	var node: Node3D = null
	if not sheet.is_empty():
		var spr := VfxMeshes.sheet_node(cue, sheet, scale, bool(def.get("ground", false)), true)
		spr.modulate = color
		if not ramp.is_empty():
			spr.modulate = Color(1.0, 1.0, 1.0, color.a)
			spr.material_override = VfxMeshes.ramp_material(sheet.tex, ramp, not bool(def.get("ground", false)), add, energy)
		elif add or not is_equal_approx(energy, 1.0):
			spr.material_override = VfxMeshes.sheet_material(sheet.tex, add, not bool(def.get("ground", false)), energy)
		spr.play("default")
		node = spr
	elif String(def.get("preset", "none")) == "none":
		return null   # 시트 전용 큐(부적 종이·횃불 불꽃)인데 파일이 없다 → 조용히 없음 (플레이스홀더는 호출자가 유지)
	elif String(def.get("preset", "")) == "beam":
		node = _make_beam(parent, color, scale, opts)
	else:
		node = _spawn_particles(String(def.get("preset", "dust")), parent, Vector3.ZERO, color, scale, Vector3.ZERO, true, Lane.MAIN, add, energy, false, ramp)
	if node == null:
		return null
	if node.get_parent() != parent:
		parent.add_child(node)
	node.position = offset
	node.name = "Vfx_" + cue
	_loop_nodes.append(node)
	return node


## 창 안 2D 반짝 (식별·장착) — 화면 좌표에 GPUParticles2D 단발. 3D 큐와 같은 이력에 남는다.
func play_ui(cue: String, screen_pos: Vector2) -> bool:
	_remember(cue)
	if not CUES.has(cue):
		_log_missing(cue)
		return false
	var def: Dictionary = CUES[cue]
	var p := VfxMeshes.ui_burst(cue, def.get("color", Color.WHITE))
	p.position = screen_pos
	_ui_root().add_child(p)
	p.emitting = true
	get_tree().create_timer(0.8, false).timeout.connect(func() -> void:
		if is_instance_valid(p):
			p.queue_free())
	return true


## 창 안 2D 이펙트가 붙는 판(CanvasLayer 95 — 대화 띠 10·화면 오버레이 90 위, 페이드 100 아래). 처음 부를 때 세운다 — play_ui(반짝)와 play_ui_glyph(붓글씨)가 같이 쓴다.
func _ui_root() -> CanvasLayer:
	if _ui_layer == null:
		_ui_layer = CanvasLayer.new()
		_ui_layer.name = "VfxUi"
		_ui_layer.layer = 95
		add_child(_ui_layer)
	return _ui_layer


## opts.radius(바깥 반지름, 유닛) → scale (#385) — 시트는 한 칸 = 지름(units × scale)이라 2r ÷ units, 없으면 링 프리셋(반지름 RING_REACH × scale)이라 r ÷ RING_REACH.
static func radius_scale(rad: float, sheet: Dictionary) -> float:
	if not sheet.is_empty():
		return 2.0 * rad / maxf(float(sheet.meta.get("units", 1.0)), 0.001)
	return rad / RING_REACH


## e2e: since_seq 이후 불린 큐 이름들 (Audio.recent와 같은 규약).
func recent(since_seq: int) -> Array[String]:
	var n := mini(seq - since_seq, history.size())
	return history.slice(history.size() - n) if n > 0 else []


func has_cue(cue: String) -> bool:
	return CUES.has(cue)


func cue_count() -> int:
	return CUES.size()


func live_count() -> int:
	_prune()
	return _live_nodes.size()


## 살아 있는 피(gore) 단발 수 — 공용 live_count()와 따로 센다(#395).
func live_gore_count() -> int:
	_prune()
	return _live_gore.size()


## 그중 평소 피(gore_low, #359) 수.
func live_gore_low_count() -> int:
	_prune()
	return _live_gore_low.size()


## 뿜기·막타 피가 들어갈 자리 (#359, game_feel_v2 §11.7): 피 칸이 찼으면 가장 오래된 평소 피(gore_low) 하나를 끈다 — 평소 피만 비킨다
## (뿜기·막타 피끼리는 밀어내지 않는다 — #395 정책 그대로, 그때는 생략). 끈 입자 노드는 숨기기만 한다: 제 타이머가 곧 풀로 돌려보낸다
## (지금 풀에 넣으면 남은 그 타이머가 다른 큐가 다시 쓰는 노드를 일찍 거둔다). 시트 노드(공방 피 시트가 오면)는 바로 지운다.
func _make_gore_room() -> void:
	_prune()
	if _live_gore.size() < MAX_GORE or _live_gore_low.is_empty():
		return
	var n: Node = _live_gore_low.pop_front()
	_live_gore.erase(n)
	evicted += 1
	if n is GPUParticles3D:
		(n as GPUParticles3D).emitting = false
		(n as GPUParticles3D).visible = false
	else:
		n.queue_free()


func _note_capped(cue: String) -> void:
	capped[cue] = int(capped.get(cue, 0)) + 1


## 살아 있는 조각(bits) 단발 수 — 불꽃 조각·먹 방울(#628), 공용·피와 따로 센다.
func live_bits_count() -> int:
	_prune()
	return _live_bits.size()


## 남아 있는 바닥 먹 자국 수(#628 — 마르는 중에 밀려나 걷히는 것은 뺀다).
func mark_count() -> int:
	_prune()
	return _marks.size()


func loop_count() -> int:
	_prune()
	return _loop_nodes.size()


## 시트가 반입돼 있는 큐인가 (assets/vfx/<cue>/).
func has_sheet(cue: String) -> bool:
	return not _sheet_for(cue).is_empty()


## 이 큐로 마지막에 만든 시트 노드 핸들 — 이름 조회(get_node_or_null("Vfx_sheet_<cue>"))는 같은 이름이 아직 안 죽은
## 채로 겹치면(#395 ② 실측 — 흑랑 자신도 blood_splat 하나를 만든다) 엉뚱한(옛) 노드를 찾는다. 여기는 만든 순간의
## 핸들을 그대로 쥐고 있다가, 이미 해제됐으면(재생이 끝나 queue_free) null로 거른다. 시트가 아닌 큐(글자·프리셋)는 없다.
func last_sheet(cue: String) -> AnimatedSprite3D:
	var n = _last_sheet.get(cue)
	return n if is_instance_valid(n) else null


## 빛 번쩍 (#615) — pos에 점광을 켜고 life초에 걸쳐 곧게 끈다(켜는 순간이 가장 밝다 — 「번쩍」, 반 수명에 절반). reach = 닿는 반경(유닛).
## 트리 밖(단위 시험의 Vfx 인스턴스)이면 null. 반환 = 쓴 점광(시험·진단).
func flash_light(pos: Vector3, color: Color, energy: float, reach: float, life: float) -> OmniLight3D:
	if not is_inside_tree() or energy <= 0.0 or reach <= 0.0 or life <= 0.0:
		return null
	var l: OmniLight3D
	if _lights.size() < LIGHT_MAX:
		l = OmniLight3D.new()
		l.name = "VfxLight%d" % _lights.size()
		l.shadow_enabled = false
		l.light_specular = 0.3   # 금속으로 들어온 몸(dungeon.md §6.7 ①)이 번들거리지 않게 반사는 낮게
		add_child(l)
		_lights.append(l)
	else:
		l = _lights[_light_next]
		_light_next = (_light_next + 1) % LIGHT_MAX
	var old: Tween = l.get_meta("tw") if l.has_meta("tw") else null
	if old and old.is_valid():
		old.kill()
	l.global_position = Vector3(pos.x, maxf(pos.y, LIGHT_LIFT), pos.z)
	l.light_color = color
	l.omni_range = reach
	l.light_energy = energy
	l.visible = true
	var tw := l.create_tween()
	tw.tween_property(l, "light_energy", 0.0, life)
	tw.tween_callback(func() -> void: l.visible = false)
	l.set_meta("tw", tw)
	return l


## 큐 표 light = [세기, 반경(유닛), 수명(초)] (+ light_color, 없으면 큐 색). 판정 반지름(opts.radius)을 받은 큐는 그만큼 넓게.
func _light_for(def: Dictionary, pos: Vector3, color: Color, opts: Dictionary) -> void:
	var spec: Array = def.light
	var reach := float(spec[1])
	if opts.has("radius"):
		reach = maxf(reach, float(opts.radius) * LIGHT_RADIUS_REACH)
	flash_light(pos, def.get("light_color", color), float(spec[0]), reach, float(spec[2]))


## 빛 번쩍 풀 크기(살아 있는 것 + 쉬는 것) — 시험.
func light_pool_size() -> int:
	return _lights.size()


## 피격 섬광 테 색 (#628 V2) — 맞은 조각 속성(DamageCalc.roll_hit element, 물리 &"") → 속성 빛 색, 치명이면 금니(속성보다 위 — 보상·치명 = 금니 §2 ⑦).
## 불·한기·벼락·살 = 원소 구조 번쩍(#632 element_burst)과 같은 표 _element_color(두 벌 두지 않는다) · 영기 = 옥빛(적 전용, D-081) · 물리·모르는 속성 = 따뜻한 흰빛.
## 부르는 쪽 = Enemy.receive_attack·receive_spell → ActorVisual.flash(…, 색).
static func hit_rim(element: StringName, crit: bool = false) -> Color:
	if crit:
		return GOLD_LEAF_LIGHT
	if element in [&"fire", &"cold", &"lightning", &"sal"]:
		return _element_color(element)
	return SOUL_SMOKE if element == &"soul" else RIM_WHITE


## 잡음 흔들림 (#628 V2 — vfx_rework §2 ② 터짐) — 지금 카메라(world/iso_camera.gd shake)에 사다리 칸 이름으로(&"hit" · &"crit" · &"skill" · &"boss" — world/camera_shake.gd LADDER).
## mult = 칸 안에서의 몫(기술 = 킥 크기 몫). 카메라가 없거나(단위 시험·트리 밖) 흔들림을 모르면 조용히 없음. 이력엔 안 남긴다(카메라 trauma가 증거).
func shake(rung: StringName, mult: float = 1.0) -> void:
	if not is_inside_tree():
		return
	var cam := get_viewport().get_camera_3d()
	if cam and cam.has_method("shake"):
		cam.shake(rung, mult)


## 큐 표 shake 키 (#628 — 보스 포효) · opts.shake로 덮을 수 있다(&"" = 끔).
func _shake_for(def: Dictionary, opts: Dictionary) -> void:
	var rung := StringName(opts.get("shake", def.get("shake", "")))
	if rung != &"":
		shake(rung)


# ---------- 내부: 파티클 프리셋 ----------

## add = 빛(가산 · 안개 끔) / 아니면 먹(섞기 · 안개) · energy = 입자 색의 선형 배율(입자 색은 그대로 선형으로 읽힌다 — 정점 색 sRGB 표시 없음).
## lane = 단발 칸(Lane — 공용 · 피 · 조각, 상한을 따로 센다, #395·#628) · 프리셋 lift = 방향에 더하는 위쪽 몫(#628 — 부르는 쪽은 수평 방향만 넘긴다).
## low = 평소 피의 밀려나는 순서만 바꾼다(#359, 피 칸에서만) — add·energy와 별개여서 먹 재질과 승인 색을 그대로 쓴다.
func _spawn_particles(preset: String, parent: Node, pos: Vector3, color: Color, scale: float, dir: Vector3, loop: bool, lane: int = Lane.MAIN, add: bool = false, energy: float = 1.0, low: bool = false, ramp: String = "") -> GPUParticles3D:
	if not PRESETS.has(preset):
		return null
	var p: GPUParticles3D = null
	if not loop:
		var free: Array = _pool.get(preset, [])
		if not free.is_empty():
			p = free.pop_back()
	if p == null:
		p = VfxMeshes.particles(preset, PRESETS[preset])
	p.visible = true   # 밀려 꺼진 평소 피(#359 _make_gore_room)는 숨긴 채 풀로 돌아온다
	var spec: Dictionary = PRESETS[preset]
	var mat := p.process_material as ParticleProcessMaterial
	mat.color = color if is_equal_approx(energy, 1.0) else Color(color.r * energy, color.g * energy, color.b * energy, color.a)
	# 풀에서 돌려 쓰는 노드라 겹침·안개를 매번 맞춘다 (#615) — 얼음 조각(shard)은 빛 받는 메시라 그대로
	var quad := p.draw_pass_1 as QuadMesh
	if quad:
		# 같은 프리셋 풀이 색띠/기존 틴트를 오간다. 노드 수·타이머는 그대로, 쉬는 노드의 원래 재질부터 복원.
		if not p.has_meta("vfx_legacy_material"):
			p.set_meta("vfx_legacy_material", quad.material)
		quad.material = p.get_meta("vfx_legacy_material")
		if not ramp.is_empty() and not spec.has("mix"):
			mat.color = Color(1.0, 1.0, 1.0, color.a)
			quad.material = VfxMeshes.ramp_material(VfxMeshes.soft_texture(), ramp, true, add, energy, true)
	if quad and quad.material is StandardMaterial3D:
		var dm := quad.material as StandardMaterial3D
		dm.blend_mode = BaseMaterial3D.BLEND_MODE_ADD if add else BaseMaterial3D.BLEND_MODE_MIX
		dm.disable_fog = add
	if dir.length_squared() > 0.01:
		mat.direction = (dir.normalized() + Vector3.UP * float(spec.get("lift", 0.0))).normalized()
	else:
		mat.direction = Vector3.UP
	p.scale = Vector3.ONE * maxf(scale, 0.05)
	p.one_shot = not loop
	p.emitting = false
	if p.get_parent() != parent:
		if p.get_parent():
			p.get_parent().remove_child(p)
		parent.add_child(p)
	if not loop:
		p.global_position = pos
		p.restart()
		p.emitting = true
		_lane_nodes(lane).append(p)
		if low and lane == Lane.GORE:
			_live_gore_low.append(p)
		# 방출 구간(lifetime × (1−explosive)) + 마지막 입자 수명 + 여유
		var total: float = float(spec.life) * (2.0 - float(spec.get("explosive", 0.0))) + 0.15
		get_tree().create_timer(total, false).timeout.connect(_recycle.bind(p, preset, lane))
	else:
		p.emitting = true
	return p


# 층 교체로 p가 먼저 해제돼도 타이머는 온다. Variant로 받아 유효성 검사 전에 타입 변환으로 실패하지 않게 한다.
func _recycle(p, preset: String, lane: int = Lane.MAIN) -> void:
	if not is_instance_valid(p):
		return
	_lane_nodes(lane).erase(p)
	if lane == Lane.GORE:
		_live_gore_low.erase(p)
	p.emitting = false
	var free: Array = _pool.get(preset, [])
	if free.size() < 8:
		# 쉬는 동안 Vfx 밑에 둔다(트리 안) — 층이 사라져도 같이 안 죽고, 종료 때 정상 해제
		if p.get_parent() != self:
			if p.get_parent():
				p.get_parent().remove_child(p)
			add_child(p)
		free.append(p)
		_pool[preset] = free
	else:
		p.queue_free()


# ---------- 내부: 링 · 기둥 ----------

## 확장하는 링. ground = 바닥에 눕힘, 아니면 카메라를 본다. hold = 수명 동안 크기 유지(선딜 표시)하다 마지막에 사라짐. 판·재질 = VfxMeshes.ring.
func _spawn_ring(parent: Node, pos: Vector3, color: Color, scale: float, life: float, ground: bool, hold: bool, add: bool = false, energy: float = 1.0) -> bool:
	var mi := VfxMeshes.ring(color, add, energy)
	var mat := mi.material_override as ShaderMaterial
	parent.add_child(mi)
	mi.global_position = pos + (Vector3(0, 0.03, 0) if ground else Vector3.ZERO)
	mi.scale = Vector3.ONE * maxf(scale, 0.05)
	if ground:
		mi.rotation_degrees.x = -90.0
	else:
		var cam := get_viewport().get_camera_3d() if is_inside_tree() else null
		if cam:
			mi.global_transform.basis = cam.global_transform.basis.scaled(Vector3.ONE * maxf(scale, 0.05))
	_live_nodes.append(mi)
	var tw := mi.create_tween()
	tw.set_parallel(true)
	if hold:
		mat.set_shader_parameter("radius", 0.85)
		mat.set_shader_parameter("alpha", 0.9)
		tw.tween_method(func(v: float) -> void: mat.set_shader_parameter("width", v), 0.14, 0.06, life)
		tw.tween_method(func(v: float) -> void: mat.set_shader_parameter("alpha", v), 0.9, 0.0, life * 0.3).set_delay(life * 0.7)
	else:
		mat.set_shader_parameter("radius", 0.2)
		mat.set_shader_parameter("alpha", 0.95)
		tw.tween_method(func(v: float) -> void: mat.set_shader_parameter("radius", v), 0.2, RING_REACH, life).set_ease(Tween.EASE_OUT)
		tw.tween_method(func(v: float) -> void: mat.set_shader_parameter("alpha", v), 0.95, 0.0, life)
	tw.chain().tween_callback(func() -> void:
		if is_instance_valid(mi):
			_live_nodes.erase(mi)
			mi.queue_free())
	return true


## 빛 기둥 — 위로 자라며 사라지는 발광 원기둥(가산 혼합).
func _spawn_pillar(parent: Node, pos: Vector3, color: Color, scale: float, life: float) -> bool:
	var mi := VfxMeshes.pillar(color)
	var m := mi.material_override as StandardMaterial3D
	parent.add_child(mi)
	mi.global_position = pos + Vector3(0, 1.2 * scale, 0)
	mi.scale = Vector3(scale, 0.2 * scale, scale)
	_live_nodes.append(mi)
	var tw := mi.create_tween()
	tw.set_parallel(true)
	tw.tween_property(mi, "scale:y", scale, life * 0.35).set_ease(Tween.EASE_OUT)
	tw.tween_property(m, "albedo_color:a", 0.75, life * 0.2)
	tw.tween_property(m, "albedo_color:a", 0.0, life * 0.6).set_delay(life * 0.4)
	tw.chain().tween_callback(func() -> void:
		if is_instance_valid(mi):
			_live_nodes.erase(mi)
			mi.queue_free())
	return true


## 바닥에 눕힌 띠 — 돌진 궤적. from→to, width = 폭(유닛). 끝이 둥근 원판 텍스처로 부드럽게. 길을 따라 먼지 3번.
func _spawn_streak(parent: Node, from: Vector3, to: Vector3, color: Color, width: float, life: float, energy: float = 1.0) -> bool:
	var seg := to - from
	seg.y = 0.0
	var len := seg.length()
	if len < 0.2:
		return false
	var dir := seg / len
	var mi := VfxMeshes.streak(len, width, color, energy)
	var m := mi.material_override as StandardMaterial3D
	parent.add_child(mi)
	var side := Vector3.UP.cross(dir).normalized()
	mi.global_transform = Transform3D(Basis(dir, side, Vector3.UP), from + seg * 0.5 + Vector3(0, 0.04, 0))
	_live_nodes.append(mi)
	var tw := mi.create_tween()
	tw.tween_property(m, "albedo_color:a", 0.0, life)
	tw.tween_callback(func() -> void:
		if is_instance_valid(mi):
			_live_nodes.erase(mi)
			mi.queue_free())
	for f in [0.2, 0.55, 0.9]:
		_spawn_particles("dust", parent, from + seg * f, DUST, 0.7, -dir, false)
	return true


## 바닥 먹 자국 (#628 V2, 큐 표 kind mark) — pos = 맞은 몸 발밑(바닥), dir = 칼이 빠지는 쪽(그쪽으로 MARK_AHEAD 앞 · 튄 방울이 그쪽).
## 판 = VfxMeshes.mark(먹 셰이더 — 자국마다 instance uniform seed로 모양이 다르다). MARK_SPREAD초에 번지고, life초에 걸쳐 가장자리부터 마른다(dry 0 → 1, ease-in —
## 젖은 채 잠깐 머물다 마른다). 상한 MARK_CAP — 넘치면 가장 오래된 것을 MARK_RETIRE초에 마저 말린다. 부모(층)와 함께 사라진다.
func _spawn_mark(parent: Node, pos: Vector3, color: Color, size: float, life: float, dir: Vector3) -> bool:
	if parent == null or not is_inside_tree() or not parent.is_inside_tree():
		return false
	_prune()
	while _marks.size() >= MARK_CAP:
		_retire_mark(_marks[0])
	var mi := VfxMeshes.mark(color)
	parent.add_child(mi)
	var d := Vector3(dir.x, 0.0, dir.z)
	var ahead := d.normalized() * MARK_AHEAD if d.length_squared() > 0.0001 else Vector3.ZERO
	mi.global_position = Vector3(pos.x, pos.y + MARK_Y, pos.z) + ahead
	# 판 +X(그림의 튄 쪽)를 dir로 — y축으로 θ 돌리면 +X → (cos θ, 0, −sin θ) (KillFx.stain과 같은 셈)
	mi.rotation.y = (atan2(-d.z, d.x) if d.length_squared() > 0.0001 else _rng.randf() * TAU) + _rng.randf_range(-0.25, 0.25)
	var full := Vector3(maxf(size, 0.05) * MARK_STRETCH, 1.0, maxf(size, 0.05))
	mi.scale = full * MARK_SPREAD_FROM
	mi.set_instance_shader_parameter(&"seed", _rng.randf() * 100.0)
	mi.set_instance_shader_parameter(&"dry", 0.0)
	var tw := mi.create_tween()
	tw.tween_property(mi, "scale", full, MARK_SPREAD).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_OUT)
	var dry := mi.create_tween()
	dry.tween_method(_mark_dry.bind(mi), 0.0, 1.0, maxf(life, 0.05)).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_IN)
	dry.tween_callback(mi.queue_free)
	mi.set_meta(&"dry", dry)
	_marks.append(mi)
	return true


## 마름 걸음 — 형 없이 받는다(층과 함께 먼저 해제돼도 트윈이 한 번 더 올 수 있다 — _recycle과 같은 이유).
func _mark_dry(v: float, mi) -> void:
	if is_instance_valid(mi):
		(mi as GeometryInstance3D).set_instance_shader_parameter(&"dry", v)


## 상한 밖으로 밀려난 자국 — 목록에서 빼고 지금 마름에서 끝까지 짧게 말려 치운다(마름 트윈을 먼저 끊는다 — 둘이 같은 값을 번갈아 쓰면 깜빡인다).
func _retire_mark(mi) -> void:
	_marks.erase(mi)
	if not is_instance_valid(mi):
		return
	var node := mi as MeshInstance3D
	var old: Variant = node.get_meta(&"dry", null)
	if old is Tween and (old as Tween).is_valid():
		(old as Tween).kill()
	var raw: Variant = node.get_instance_shader_parameter(&"dry")
	var from := float(raw) if raw != null else 0.0
	var tw := node.create_tween()
	tw.tween_method(_mark_dry.bind(node), from, 1.0, MARK_RETIRE)
	tw.tween_callback(node.queue_free)


## 드랍 광선 — 얇은 가산 원기둥(위로 옅어짐, VfxMeshes.beam — opts height·core #379) + 천천히 오르는 입자 루프. 부모(FloorItem) 밑에 붙어 줍히면 같이 사라진다.
func _make_beam(parent: Node, color: Color, scale: float, opts: Dictionary = {}) -> Node3D:
	var root := VfxMeshes.beam(color, scale, opts)
	parent.add_child(root)
	_spawn_particles("rise", root, Vector3.ZERO, color, 0.6 * scale, Vector3.ZERO, true)
	return root


# ---------- 내부: 화면 오버레이 ----------

## vignette = 가장자리만 물듦(피격) / flash = 화면 전체 잠깐(포효). 종류당 ColorRect 하나를 재사용.
## 장소를 바꾸는 화면 전환(문·서낭단·계단·사망)은 여기가 아니라 먹 번짐 판(#285, ui/ink_wipe.gd — HUD 밑 판, 셸이 덮고 걷는다).
## strength = 비네트 최대 세기(기본 0.55 = 피격). 치명처럼 **자주 오는** 화면 연출은 낮춰야 눈이 지치지 않는다.
func _screen(kind: String, color: Color, life: float, strength: float = 0.55) -> void:
	if _screen_layer == null:
		_screen_layer = CanvasLayer.new()
		_screen_layer.name = "VfxScreen"
		_screen_layer.layer = 90
		add_child(_screen_layer)
	var rect: ColorRect = _screen_rects.get(kind)
	if rect == null:
		rect = ColorRect.new()
		rect.name = kind
		rect.mouse_filter = Control.MOUSE_FILTER_IGNORE
		_screen_layer.add_child(rect)
		rect.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
		if kind == "vignette":
			rect.material = VfxMeshes.vignette_material()
		_screen_rects[kind] = rect
	rect.visible = true
	if kind == "element_flash":
		var old_tw: Variant = rect.get_meta("element_tw") if rect.has_meta("element_tw") else null
		if old_tw is Tween and old_tw.is_valid():
			old_tw.kill()
	var tw := rect.create_tween()
	if kind == "element_flash":
		tw.set_pause_mode(Tween.TWEEN_PAUSE_STOP)
		rect.set_meta("element_tw", tw)
	if kind == "vignette":
		var sm := rect.material as ShaderMaterial
		sm.set_shader_parameter("tint", color)
		sm.set_shader_parameter("strength", strength)
		tw.tween_method(func(v: float) -> void: sm.set_shader_parameter("strength", v), strength, 0.0, life)
	else:
		rect.color = Color(color.r, color.g, color.b, strength if kind == "element_flash" else 0.35)
		tw.tween_property(rect, "color:a", 0.0, life)
	tw.tween_callback(func() -> void: rect.visible = false)


# ---------- 내부: 시트 (assets/vfx/<cue>/) ----------

## 큐의 시트·메타가 있으면 {"frames": SpriteFrames, "meta": Dictionary}, 없으면 {}. 결과는 캐시(없음도).
func _sheet_for(cue: String) -> Dictionary:
	if _sheets.has(cue):
		return _sheets[cue]
	var sheet_path := "%s%s/%s_sheet.png" % [sheet_dir, cue, cue]
	var meta_path := "%s%s/%s_meta.json" % [sheet_dir, cue, cue]
	var entry := {}
	if ResourceLoader.exists(sheet_path) and ResourceLoader.exists(meta_path):
		var meta_res = load(meta_path)
		var meta: Dictionary = meta_res.data if meta_res is JSON and meta_res.data is Dictionary else {}
		var tex := load(sheet_path) as Texture2D
		if tex and meta.has("cols") and meta.has("fw") and meta.has("fh") and meta.has("total"):
			var sf := SpriteFrames.new()
			sf.set_animation_speed("default", float(meta.get("fps", 12.0)))
			sf.set_animation_loop("default", bool(meta.get("loop", false)))
			var cols := int(meta.cols)
			var fw := int(meta.fw)
			var fh := int(meta.fh)
			for f in int(meta.total):
				var at := AtlasTexture.new()
				at.atlas = tex
				at.region = Rect2((f % cols) * fw, floori(f / float(cols)) * fh, fw, fh)
				sf.add_frame("default", at)
			entry = {"frames": sf, "meta": meta, "tex": tex}   # tex = 시트 통째 — glyph 판 셰이더가 칸을 스스로 고른다 (#280)
	_sheets[cue] = entry
	return entry


## lane = 단발 칸(#395 피 · #628 조각 — 상한을 따로 센다) · low = 평소 피(#359, 피 칸에서만).
func _spawn_sheet(cue: String, sheet: Dictionary, parent: Node, pos: Vector3, scale: float, def: Dictionary, opts: Dictionary, lane: int = Lane.MAIN, add: bool = false, energy: float = 1.0, low: bool = false) -> bool:
	_prune()
	if not _is_big(def, opts) and _lane_full(lane):
		_note_capped(cue)
		return false
	var spr := VfxMeshes.sheet_node(cue, sheet, scale, bool(def.get("ground", false)), false)
	spr.modulate = opts.get("color", def.get("color", Color.WHITE))   # 흰 먹 획을 큐 색으로 물들인다 (D-075)
	var ramp := _ramp_for(def, opts)
	# 빛 시트(#615): 가산·안개 끔·1.0을 넘는 심 — 기본 스프라이트 재질로는 안 되는 셋이라 같은 일을 하는 재질로 덮는다(VfxMeshes.sheet_material)
	if not ramp.is_empty():
		spr.modulate = Color(1.0, 1.0, 1.0, spr.modulate.a)
		spr.material_override = VfxMeshes.ramp_material(sheet.tex, ramp, not bool(def.get("ground", false)), add, energy)
	elif add or not is_equal_approx(energy, 1.0):
		spr.material_override = VfxMeshes.sheet_material(sheet.tex, add, not bool(def.get("ground", false)), energy)
	parent.add_child(spr)
	spr.global_position = pos + (Vector3(0, 0.03, 0) if def.get("ground", false) else Vector3.ZERO)
	var dir: Vector3 = opts.get("dir", Vector3.ZERO)
	var flip_random := bool(def.get("flip_random", false))
	if dir.length_squared() > 0.01 and def.get("ground", false):
		spr.rotation.y = atan2(dir.x, dir.z)
	elif dir.length_squared() > 0.01 and not flip_random:
		# 빌보드 시트(참격 반달)는 회전 대신 화면 좌/우로 뒤집는다: 카메라 오른쪽 벡터와 dir 내적이 음수 = 화면 왼쪽으로 베는 휘두름 (#60)
		var cam := get_viewport().get_camera_3d() if is_inside_tree() else null
		if cam and dir.dot(cam.global_transform.basis.x) < 0.0:
			spr.flip_h = true
	if flip_random:
		# 먼지처럼 천 번 보는 시트(#217): 방향이 아니라 좌우를 무작위로 뒤집어 반복을 가린다 (game_feel_v2 §6.1) — 게임 RNG가 아닌 Vfx 몫 _rng
		spr.flip_h = _rng.randf() < 0.5
	# 수명이 정해진 단발(opts.life — 적 선딜 등)은 시트 길이를 그 수명에 맞춘다: 링이 공격 임팩트에 딱 끝난다 (#56)
	var life := float(opts.get("life", 0.0))
	if life > 0.0 and not spr.sprite_frames.get_animation_loop("default"):
		var n := spr.sprite_frames.get_frame_count("default")
		var fps := spr.sprite_frames.get_animation_speed("default")
		if n > 0 and fps > 0.0:
			spr.speed_scale = (n / fps) / life
	# 커지며 옅어지는 단발 (#280 먹 파문): grow = 처음 크기 배율 → 제 크기(ease-out), fade = 시트가 끝날 때 투명. 시안 ground_ripple(지름 1→3, (1−k)^0.8)
	if not spr.sprite_frames.get_animation_loop("default") and (def.has("grow") or bool(def.get("fade", false))):
		var dur := _sheet_seconds(spr)
		var tw := spr.create_tween().set_parallel(true)
		if def.has("grow"):
			var full := spr.scale
			spr.scale = full * float(def.grow)
			tw.tween_property(spr, "scale", full, dur).set_ease(Tween.EASE_OUT).set_trans(Tween.TRANS_CUBIC)
		if bool(def.get("fade", false)):
			tw.tween_property(spr, "modulate:a", 0.0, dur)
	spr.play("default")
	_lane_nodes(lane).append(spr)
	if low and lane == Lane.GORE:
		_live_gore_low.append(spr)
	_last_sheet[cue] = spr   # 핸들 기록(#395 ②) — 이름 겹침과 무관하게 last_sheet(cue)가 "방금 이것" 하나를 돌려준다.
	spr.animation_finished.connect(func() -> void:
		_lane_nodes(lane).erase(spr)
		if lane == Lane.GORE:
			_live_gore_low.erase(spr)
		spr.queue_free())
	return true


## 단발 시트 한 바퀴의 실제 초 (프레임 수 ÷ fps ÷ 재생 배율).
func _sheet_seconds(spr: AnimatedSprite3D) -> float:
	var n := spr.sprite_frames.get_frame_count("default")
	var fps := spr.sprite_frames.get_animation_speed("default")
	if n <= 0 or fps <= 0.0:
		return 0.3
	return float(n) / fps / maxf(spr.speed_scale, 0.01)


# ---------- 내부: 한자 획 쓰기 (glyph, D-085 · #280 · vfx.md §8.10) ----------
# 판 하나(카메라를 본다) + 셰이더가 시트의 칸을 골라 흰 먹을 틴트 사다리로 물들이고, 오른쪽 아래 먹 그림자·옅은 번짐을 두르고,
# 흩어질 때 가장자리부터 잡음 순서로 스러진다. 먹방울 = MultiMesh 원판(메타 points 자리에서 바깥·위로). 시간은 glyph_frame·glyph_burst(순수 함수).
# 바닥 글씨(ground, #281) = 판을 바닥에 눕히고(glyph_ground_basis) 깊이를 먼저 쓴다 · 뭉침 끝(end gather) = 흩어지는 대신 작게 뭉쳐 조각 자리로(glyph_gather) → 파문·빛(glyph_glow) → 옅어짐(fade).
# 왜 AnimatedSprite3D가 아닌가: 알파만 줄여서는 「가장자리부터 스러짐」·그림자·금니 사다리를 못 그린다. 방울을 GPU 입자로 안 한 이유 =
# 점마다 방향을 주는 방출 규칙을 화면 없이 맞추기 어렵고, 48개 × 0.6초는 CPU로도 가볍다.

## 쓰기 칸 — 쓰기 시작 뒤 t초(음수 = 아직)에 보일 칸 0..n−1. 시안 GlyphSprite.draw와 같다: int(t ÷ write × n), 끝 칸에서 멈춘다.
static func glyph_frame(t: float, write: float, n: int) -> int:
	if n <= 1 or t <= 0.0:
		return 0
	if write <= 0.0:
		return n - 1
	return mini(n - 1, int(t / write * float(n)))


## 흩어짐 진행 0..1 — 장면 시각 u, 흩어지기 시작 start초(= delay + write + hold), out초에 걸쳐.
static func glyph_burst(u: float, start: float, out: float) -> float:
	if u <= start:
		return 0.0
	if out <= 0.0:
		return 1.0
	return clampf((u - start) / out, 0.0, 1.0)


## 한 장면의 길이(초) = delay + write + hold + (흩어짐: out + 방울 꼬리 | 뭉침: gather + linger + out).
static func glyph_total(def: Dictionary) -> float:
	var head := float(def.get("delay", 0.0)) + float(def.get("write", 0.55)) + float(def.get("hold", 0.6))
	if String(def.get("end", "")) == "gather":
		return head + float(def.get("gather", 0.35)) + float(def.get("linger", 0.0)) + float(def.get("out", 0.35))
	return head + float(def.get("out", 0.35)) + GLYPH_DROP_TAIL


## 뭉침 진행 0..1 (#281) — 멈춤이 끝난 start초부터 dur초에 걸쳐 ease-out(세제곱): 빨리 줄다가 조각 자리에 살며시 닿는다 (시안 ease_out).
static func glyph_gather(u: float, start: float, dur: float) -> float:
	var x := glyph_burst(u, start, dur)
	return 1.0 - pow(1.0 - x, 3.0)


## 뭉친 글씨 밑 바닥 빛의 세기 (#281) — 닿은 뒤 t초(음수 = 아직): GLYPH_GLOW_RAMP초에 차고 (0.8 + 0.2 sin 9t)로 맥박친다 (시안 soft_glow).
static func glyph_glow(t: float, amount: float) -> float:
	if t < 0.0:
		return 0.0
	return amount * clampf(t / GLYPH_GLOW_RAMP, 0.0, 1.0) * (0.8 + 0.2 * sin(t * GLYPH_GLOW_PULSE))


## 바닥에 눕힌 글씨 판의 방향 (#281) — 판의 +X = 카메라 오른쪽, +Y(글자 위) = 카메라에서 먼 쪽(화면 위), +Z(법선) = 위.
## 직교 카메라가 내려다보는 35.264°라 바닥의 세로가 sin 35.264° = 0.577로 눌려 보인다(시안 SQUASH). 카메라가 없으면 위에서 본 판(글자 위 = −Z).
static func glyph_ground_basis(cam: Basis) -> Basis:
	var y := Vector3(-cam.z.x, 0.0, -cam.z.z)   # 카메라가 보는 쪽을 바닥에 눕힌 것 = 화면 위
	if y.length_squared() < 0.000001:
		return Basis(Vector3.RIGHT, Vector3.FORWARD, Vector3.UP)
	y = y.normalized()
	var x := y.cross(Vector3.UP).normalized()   # = 화면 오른쪽 (카메라가 기울어도 바닥 위에서 y와 직각)
	return Basis(x, y, Vector3.UP)


## 흰 먹 → 틴트 사다리 — 짓는 쪽 VfxMeshes.glyph_ramp(#418), 바깥 이름은 그대로.
static func glyph_ramp(tint: Color) -> Array[Color]:
	return VfxMeshes.glyph_ramp(tint)


## 글자 판 노드(트리 밖) + 상태 — 짓는 쪽은 VfxMeshes.make_glyph(#418), 여기는 되넘김(단위 테스트·_spawn_glyph가 이 이름으로 부른다).
## 반환 = {root, body, mat, mm, parts, n, delay, write, hold, out, rise, w, h, ground, gather…} — _spawn_glyph가 자리에 붙이고 시간을 돌린다.
func make_glyph(cue: String, sheet: Dictionary, def: Dictionary, scale: float, color: Color) -> Dictionary:
	return VfxMeshes.make_glyph(cue, sheet, def, scale, color)


## 판을 둘 자리 — 카메라를 보는 판(판의 +Z = 카메라 쪽 → 앞면·똑바로, 직교 카메라는 돌지 않는다) / 바닥에 눕힌 판(#281, 바닥 GLYPH_GROUND_LIFT 위).
func glyph_transform(pos: Vector3, ground: bool) -> Transform3D:
	if ground:
		return Transform3D(glyph_ground_basis(_camera_basis()), pos + Vector3(0.0, GLYPH_GROUND_LIFT, 0.0))
	return Transform3D(_camera_basis(), pos)


## 큰 순간의 글자는 단발 상한(MAX_LIVE)에 걸려 빠지지 않는다(#281 — 흑랑 처치처럼 이펙트가 몰리는 순간이 글자의 자리다). 글자는 드물다(D-085 큰 순간 여섯).
func _spawn_glyph(cue: String, sheet: Dictionary, parent: Node, pos: Vector3, scale: float, def: Dictionary, opts: Dictionary) -> bool:
	_prune()
	if sheet.get("tex") == null:
		return false
	var st := make_glyph(cue, sheet, def, scale, opts.get("color", def.get("color", Color.WHITE)))
	var root: Node3D = st.root
	parent.add_child(root, true)   # 읽히는 이름 — 연달아 오르면 Vfx_glyph_glyph_do2 (e2e·dev가 이름으로 찾는다)
	root.global_transform = glyph_transform(pos, bool(st.ground))
	st["parent"] = parent   # 뭉친 글씨가 닿을 때 파문(land 큐)을 같은 부모에
	_live_nodes.append(root)
	var total := glyph_total(def)
	var tw := root.create_tween()
	tw.tween_method(_glyph_step.bind(st), 0.0, total, total)
	tw.tween_callback(_glyph_done.bind(root))
	return true


## 장면 시각 u초의 모습 — 칸 · 흩어짐(또는 뭉침) · 판 크기 · 방울. 트윈이 매 프레임 부르고, 단위 테스트도 u를 골라 직접 부른다.
func _glyph_step(u: float, st: Dictionary) -> void:
	var node = st.body   # 형 없이 먼저 받는다 — 해제된 객체를 형 있는 변수에 넣으면 그 자리에서 오류 (_recycle과 같은 이유)
	if not is_instance_valid(node):
		return
	var body: MeshInstance3D = node
	var mat: ShaderMaterial = st.mat
	var delay: float = st.delay
	var start: float = delay + float(st.write) + float(st.hold)
	body.visible = u >= delay
	mat.set_shader_parameter("frame", float(glyph_frame(u - delay, st.write, st.n)))
	if bool(st.get("gather", false)):
		_glyph_gather_step(u, start, st)
		return
	var q := glyph_burst(u, start, st.out)
	mat.set_shader_parameter("burst", q)
	body.scale = Vector3.ONE * (1.0 + GLYPH_BURST_GROW * q)
	_glyph_drops(st, u - start)


## 뭉침 (#281, 시안 after_boss_v3 HOLD_END → LAND): 멈춤이 끝나면 gather초에 판이 gather_scale로 줄며 조각 자리(gather_at)로 가고(ease-out),
## 닿는 순간 land 큐(흰 먹 파문)를 한 번 부르고 바닥 빛이 차오른다 → linger초 머물고 → out초에 글씨·빛이 함께 옅어진다(fade).
func _glyph_gather_step(u: float, start: float, st: Dictionary) -> void:
	var body: MeshInstance3D = st.body
	var mat: ShaderMaterial = st.mat
	var g := glyph_gather(u, start, st.gather_sec)
	var s := lerpf(1.0, float(st.gather_scale), g)
	body.scale = Vector3(s, s, 1.0)
	body.position = (st.gather_at as Vector3) * g
	var land := start + float(st.gather_sec)
	var fade := 1.0 - glyph_burst(u, land + float(st.linger), st.out)
	mat.set_shader_parameter("fade", fade)
	var gm: ShaderMaterial = st.get("glow_mat")
	if gm != null:
		var k := glyph_glow(u - land, float(st.glow_amount)) * fade
		gm.set_shader_parameter("strength", k)
		var gn = st.get("glow")
		if is_instance_valid(gn):
			(gn as Node3D).visible = k > 0.0
	if u >= land and not bool(st.landed):
		st["landed"] = true
		_glyph_land(st)


## 뭉친 글씨가 조각 자리에 닿는 순간 — land 큐(흰 먹 파문)를 그 자리 바닥에. 트리 밖(단위 테스트)이면 부르지 않는다.
## 봉인 조각 아이템이 생기면(#167~#169) 이 자리에 그 드랍이 놓인다 — 지금은 좌표만 (vfx.md §8.11 ⑤).
func _glyph_land(st: Dictionary) -> void:
	var cue := String(st.get("land", ""))
	var root = st.root
	var parent = st.get("parent")
	if cue == "" or not CUES.has(cue) or not is_inside_tree() or not is_instance_valid(root) or not is_instance_valid(parent) or not (root as Node3D).is_inside_tree():
		return
	var spot: Vector3 = (root as Node3D).global_transform * (st.gather_at as Vector3)
	if bool(st.ground):
		spot.y -= GLYPH_GROUND_LIFT   # 바닥 시트는 제 높이(+0.03)를 스스로 더한다
	play(cue, spot, {"parent": parent, "life": float(CUES[cue].get("life", 0.0))})


## 먹방울 — 흩어지기 시작 뒤 td초(음수 = 아직). 자리에서 바깥으로(자리 × 2.2 × 배율) + 옆 흔들림 + 위로(rise), 살짝 더 오르거나(rise ≥ 0) 떨어진다.
## 수명 = out + 꼬리, 갈수록 투명·작아진다(시안: 반지름 × (0.6 + 0.4 × 남은 몫)).
func _glyph_drops(st: Dictionary, td: float) -> void:
	var mm: MultiMesh = st.mm
	if mm == null:
		return
	var life: float = float(st.out) + GLYPH_DROP_TAIL
	if td < 0.0 or td >= life:
		mm.visible_instance_count = 0
		return
	mm.visible_instance_count = -1
	var rise: float = st.rise
	var c: Color = st.color
	var parts: Array = st.parts
	for i in parts.size():
		var d: Array = glyph_drop(parts[i], td, rise, life)
		var p: Vector2 = d[0]
		var s: float = d[1]
		mm.set_instance_transform(i, Transform3D(Basis.from_scale(Vector3(s, s, 1.0)), Vector3(p.x, p.y, 0.02)))
		mm.set_instance_color(i, Color(c.r, c.g, c.b, float(d[2])))


## 먹방울 하나 — [자리(판 평면 유닛, 위 +y), 지름, 알파]. part = [처음 자리, 퍼지는 배율, 옆 흔들림, 반지름], 흩어지기 시작 뒤 td초, life = out + 꼬리.
## 시안 Glyph.draw: 속도 = 자리 × 2.2 × 배율 + (옆, rise) · 오르는 방울은 27px·q², 떨어지는 방울은 90px·q²(÷ 65.45px/유닛) · 지름 × (0.6 + 0.4 × 남은 몫).
## 순수 함수 — MultiMesh는 헤드리스(더미 렌더러)에서 인스턴스 값을 되돌려 주지 않아 단위 테스트가 여기를 잰다.
static func glyph_drop(part: Array, td: float, rise: float, life: float) -> Array:
	var k := clampf(1.0 - td / maxf(life, 0.001), 0.0, 1.0)
	var p0: Vector2 = part[0]
	var v := p0 * 2.2 * float(part[1]) + Vector2(float(part[2]), rise)
	var acc := 0.41 if rise >= 0.0 else -1.37
	var p := p0 + v * td + Vector2(0.0, acc * td * td)
	return [p, float(part[3]) * (0.6 + 0.4 * k) * 2.0, k]


func _glyph_done(root) -> void:
	if not is_instance_valid(root):
		return
	_live_nodes.erase(root)
	root.queue_free()


## 카메라를 보는 방향(판의 +Z = 카메라 쪽). 트리 밖·카메라 없음 = 월드 그대로.
func _camera_basis() -> Basis:
	var cam := get_viewport().get_camera_3d() if is_inside_tree() and get_viewport() else null
	return cam.global_transform.basis.orthonormalized() if cam else Basis.IDENTITY


# ---------- 화면 고정 붓글씨 (ui glyph, #284 · vfx.md §8.12) ----------
# 지역 이름 배너(AreaTitle)·퀘스트 완료 完(Npc)이 부른다. 월드 글자와 같은 시트·같은 식(VfxMeshes.GLYPH_SHADER의 canvas_item 판)을 창에 붙은 ColorRect로 그린다 —
# 카메라·줌을 안 따르고 창 높이의 몇 %로 자리를 잡는다(1280×720 · 1920×1080이 같은 비율). 쓰기·멈춤·걷힘 초는 큐 표 값 그대로(glyph_frame · glyph_burst), 먹방울은 없다.
# 왜 이 길인가(가장 가벼운 길)와 기각한 대안은 vfx_meshes.gd 같은 절.
# 시계 = Vfx 자신의 _process(오토로드라 판이 멈춰도 돈다) — 판이 멈추거나 UI 창이 열려 있으면(ui_glyphs_covered) 글씨를 숨기고 시계를 세운다(후속, vfx_log §8.12).

## 화면 글씨 시계가 한 프레임에 세는 최대 초 — 끊김(층을 짓는 0.3~1초 · 첫 그림 끊김)이 큰 델타로 와도 기다림·첫 획을 안 삼킨다(ui/area_title.gd의 MAX_STEP과 같은 값).
const UI_GLYPH_MAX_STEP := 0.05

var _ui_glyphs: Dictionary = {}   # cue -> Control — 살아 있는 화면 글씨. 같은 큐를 다시 부르면 앞엣것을 걷는다(마지막 하나만 선다)
var _ui_live: Array[Dictionary] = []   # 지금 쓰이는 글씨의 상태(make_ui_glyph 사전 + u 장면 시계 + total 길이) — _process가 돌린다


## 화면 글씨 한 장면의 길이(초) = delay + write + hold + out — 월드 글자와 달리 먹방울 꼬리가 없다.
static func ui_glyph_total(def: Dictionary) -> float:
	return float(def.get("delay", 0.0)) + float(def.get("write", 0.55)) + float(def.get("hold", 0.6)) + float(def.get("out", 0.35))


## 창 크기(px, 캔버스 좌표) — stretch가 canvas_items라 창이 얼마든 1280×720 그대로다. 트리 밖(단위 시험)도 같은 값.
func _view_size() -> Vector2:
	var vp := get_viewport() if is_inside_tree() else null
	return vp.get_visible_rect().size if vp != null else Vector2(1280.0, 720.0)


## 화면 글자 판(트리 밖) + 상태. opts = {at: 글자 가운데의 창 비율 (기본 큐 표 ui_at → 창 한가운데), color, view: 창 크기(px, 기본 지금 창)}.
## 큐가 없거나 시트가 없으면 {} — 부르는 쪽(AreaTitle)이 한글만 띄운다. 짓는 쪽 = VfxMeshes.make_ui_glyph. 이력(recent)에는 만들 때 남는다 — 시계는 부르는 쪽 몫
## (play_ui_glyph = Vfx 시계(_process) · AreaTitle = 제 _process 시계 — 둘 다 끊김을 거른다).
func make_ui_glyph(cue: String, opts: Dictionary = {}) -> Dictionary:
	_remember(cue)
	if not CUES.has(cue):
		return {}
	var def: Dictionary = CUES[cue]
	var sheet := _sheet_for(String(def.get("sheet", cue)))
	if sheet.is_empty() or sheet.get("tex") == null:
		return {}
	var at: Vector2 = opts.get("at", def.get("ui_at", Vector2(0.5, 0.5)))
	var view: Vector2 = opts.get("view", _view_size())
	return VfxMeshes.make_ui_glyph(cue, sheet, def, opts.get("color", def.get("color", Color.WHITE)), view, at)


## 장면 시각 u초의 모습 — 칸 · 흩어짐(가장자리부터 스러짐 + 판이 살짝 커짐). 시계가 매 프레임 부르고, 단위 시험도 u를 골라 직접 부른다.
func ui_glyph_step(u: float, st: Dictionary) -> void:
	var node = st.root   # 형 없이 먼저 받는다 — 해제된 객체를 형 있는 변수에 넣으면 그 자리에서 오류 (_glyph_step과 같은 이유)
	if not is_instance_valid(node):
		return
	var box: ColorRect = node
	var mat: ShaderMaterial = st.mat
	var delay: float = st.delay
	var q := glyph_burst(u, delay + float(st.write) + float(st.hold), st.out)
	box.visible = u >= delay
	mat.set_shader_parameter("frame", float(glyph_frame(u - delay, st.write, st.n)))
	mat.set_shader_parameter("burst", q)
	box.scale = Vector2.ONE * (1.0 + GLYPH_BURST_GROW * q)


## 화면 고정 붓글씨 한 장면 — 큐 표 cue의 시트를 창 위에 쓴다(쓰기 → 멈춤 → 걷힘, 끝나면 스스로 사라진다). 시계는 Vfx._process — 판이 멈추거나 UI 창이 열리면 가려지고 시계도 선다.
## opts = make_ui_glyph의 것 + parent: Node (기본 Vfx 창 판 CanvasLayer 95 — 대화 띠(10) 위). 반환 = 글자 판(ColorRect) — 큐·시트가 없으면 null(이력엔 남는다).
## 같은 큐가 아직 떠 있으면 그것을 걷고 새로 쓴다.
func play_ui_glyph(cue: String, opts: Dictionary = {}) -> Control:
	var st := make_ui_glyph(cue, opts)
	if st.is_empty():
		_log_missing(cue)
		return null
	var parent: Node = opts.get("parent", _ui_root())
	if parent == null or not is_instance_valid(parent):
		(st.root as Node).free()
		return null
	var old = _ui_glyphs.get(cue)
	if is_instance_valid(old):
		(old as Node).queue_free()
	var box: ColorRect = st.root
	parent.add_child(box, true)   # 읽히는 이름 — 겹치면 UiGlyph_glyph_wan2
	_ui_glyphs[cue] = box
	if not box.is_inside_tree():
		return box   # 트리 밖(단위 시험) — 시계가 안 선다. 시험이 ui_glyph_step을 직접 부른다
	st["u"] = 0.0
	st["total"] = ui_glyph_total(CUES[cue])
	_ui_live.append(st)
	set_process(true)
	return box


## 화면 글씨 시계 — 살아 있는 글씨마다 장면 시각(u)을 센다. 가려지면(ui_glyphs_covered) 글씨를 숨기고 시계를 세웠다가 풀리면 이어 쓴다. 다 쓰면 스스로 걷는다.
## 왜 트윈이 아닌가: 트윈은 판이 멈춰도(Vfx가 ALWAYS라) 같이 돌고 가림·멈춤을 못 넣는다 — 한 프레임에 MAX만 세는 시계라 끊김에도 박자가 그대로다(AreaTitle과 같다).
func _process(delta: float) -> void:
	if _ui_live.is_empty():
		set_process(false)
		return
	var covered := ui_glyphs_covered()
	for i in range(_ui_live.size() - 1, -1, -1):
		var st: Dictionary = _ui_live[i]
		var node = st.root
		if not is_instance_valid(node) or (node as Node).is_queued_for_deletion():
			_ui_live.remove_at(i)   # 걷힌(같은 큐를 다시 불러 갈아 끼운 · 부모와 함께 사라진) 글씨
			continue
		if covered:
			(node as CanvasItem).visible = false
			continue
		st["u"] = float(st.u) + minf(delta, UI_GLYPH_MAX_STEP)
		if float(st.u) >= float(st.total):
			_ui_live.remove_at(i)
			(node as Node).queue_free()
			continue
		ui_glyph_step(float(st.u), st)


## 화면 글씨를 가릴 때인가 — 판이 멈췄거나(Esc 메뉴·타이틀·첫 여정 컷인 — Main.pause_world) UI 창(가방·반닫이·상점 …: group panel_ui 중 Esc로 닫히는 것, PanelUi)이 열려 있다.
## 왜 레이어 순서가 아닌가: HUD(창·메뉴·타이틀·컷인)는 CanvasLayer 1이라 대화 띠(10) 밑이다 — 完이 대화 중에 보이려면 띠 위(95)여야 하고, 그러면 창 위에도 얹힌다.
## 둘을 한 판에서 다 맞출 수 없고(HUD를 띠 위로 올리면 PD가 승인한 띠 연출의 겹침이 바뀐다) 대화 중엔 창이 없다(띠가 열 때 닫는다) — 그래서 레이어는 두고 가림으로 푼다.
## 오토로드·PanelUi 이름을 쓰지 않는다(단위 시험 -s 컴파일) — 그룹과 duck 속성으로.
func ui_glyphs_covered() -> bool:
	if not is_inside_tree():
		return false
	var tree := get_tree()
	if tree.paused:
		return true
	for n in tree.get_nodes_in_group("panel_ui"):
		var c := n as CanvasItem
		if c != null and c.is_visible_in_tree() and bool(n.get("closable_by_esc")):
			return true
	return false


## 이 큐로 마지막에 띄운 화면 글씨 — 살아 있을 때만(끝났거나 걷혔으면 null). e2e·dev가 본다.
func ui_glyph(cue: String) -> Control:
	var n = _ui_glyphs.get(cue)
	return n if is_instance_valid(n) and not (n as Node).is_queued_for_deletion() else null


# ---------- 스킬 타격 범위 (area, #385 · vfx.md §9) ----------
# 판정이 계산한 영역(HitArea 사전)을 그대로 바닥에 — 먹은 경계 **안쪽**으로만 칠한다(먹 바깥 끝 = 판정 경계, 「적 몸이 먹에 닿으면 맞는다」).
# 시전 순간 옅은 예고(= 칼이 닿는 순간 판정할 자리·모양 — 판정도 그 틱에, #400) → 칼이 닿는 순간 도장(stamp_area — 판정·피해·타격 소리와 같은 틱) → 마르며 흩어짐.
# 왜 셰이더 판 한 장인가: 부채꼴 각·띠 길이가 시전마다 달라 텍스처로는 모양마다 그림이 필요하다 — 부호 거리(SDF)면 숫자(uniform)뿐이고,
# 같은 식을 HitArea.sdf로 옮겨 두면 화면 없이도 「그린 경계 = 판정 경계」를 잰다. 대안 Decal 노드 = 불빛을 받아 굴에서 흰 먹이 회색이 되고
# 상자 안 적 몸에도 찍힌다 → 기각. 늘 떠 있는 조준 표시(#82) = 판정과 다른 순간·자리를 그려 PD가 지웠다(#116) → 시전한 그 판정만.

## 판 높이·여백·그리는 순서 = 짓는 쪽 값이라 VfxMeshes에 있다 — 여기 이름은 되넘김(바깥 API 그대로, #418).
const AREA_LIFT := VfxMeshes.AREA_LIFT
const AREA_PAD := VfxMeshes.AREA_PAD
const AREA_PRIORITY := VfxMeshes.AREA_PRIORITY
## 예고 — 이 초에 차오르고, 칼이 닿을 때까지 AREA_PREVIEW_FROM → 1로 짙어진다(ease-in — 가까워질수록 짙다).
const AREA_PREVIEW_IN := 0.1
const AREA_PREVIEW_FROM := 0.55
## 칼이 닿는 시각을 이만큼 넘겨도 도장이 안 오면(층 이동 등) 예고를 걷는다.
const AREA_GRACE := 0.3
## 도장 없이 걷힐 때(쓰러짐 · 도장이 끝내 안 옴) 예고가 옅어지는 시간.
const AREA_CANCEL := 0.12


## 스킬 타격 범위를 바닥에 (#385) — area = HitArea 사전(판정이 쓴 그 사전), impact_in = 칼이 닿기까지 초(0 이하 = 지금 도장 — 부적 터짐).
## 옅은 예고가 깔리고 stamp_area()가 불리면 도장 → 마름 → 스스로 사라진다. opts = {cue: 큐 표 줄(기본 skill_area), color, parent}.
## 반환 = 판 노드(부모가 없으면 null). 이력엔 늘 남는다(e2e) — 도장은 "<cue>_stamp". 판 메타 `area` = 받은 영역(e2e가 판정과 대조).
func play_area(area: Dictionary, impact_in: float, opts: Dictionary = {}) -> Node3D:
	var cue := String(opts.get("cue", "skill_area"))
	_remember(cue)
	if area.is_empty() or not CUES.has(cue):
		_log_missing(cue)
		return null
	var parent: Node = opts.get("parent", _root())
	if parent == null:
		return null
	var def: Dictionary = CUES[cue]
	var st := make_area(area, def, opts.get("color", def.get("color", WHITE_INK)))
	var node: MeshInstance3D = st.node
	st.erase("node")   # 판 메타에 판 자신을 넣지 않는다(고리)
	st["cue"] = cue
	st["impact"] = maxf(impact_in, 0.0)
	parent.add_child(node, true)   # 읽히는 이름 — Vfx_skill_area, Vfx_skill_area2 …
	node.global_transform = st.xform
	node.set_meta(&"area", area.duplicate())
	node.set_meta(&"area_state", st)
	_prune()
	_live_nodes.append(node)   # 단발 상한(MAX_LIVE)에 안 걸린다 — 시전마다 하나(쿨이 막는다). 글자와 같은 까닭(이펙트가 몰리는 순간이 제 자리)
	if impact_in <= 0.0:
		stamp_area(node)
	else:
		var total := impact_in + AREA_GRACE
		var tw := node.create_tween()
		tw.tween_method(_area_preview_step.bind(st), 0.0, total, total)
		tw.tween_callback(_area_expire.bind(node))
		st["tween"] = tw
	return node


## 칼이 닿는 순간 — 도장 (PlayerCombat._skill_impact가 타격 소리와 같은 틱에). 한 판에 한 번 · 해제된 판·걷히는 판은 그냥 둔다.
## 형 없이 받는다 — 층 이동으로 판이 먼저 해제돼도 타이머는 온다(_recycle과 같은 이유).
func stamp_area(n) -> void:
	var st := _area_state(n)
	if st.is_empty() or bool(st.stamped) or bool(st.done):
		return
	st["stamped"] = true
	_remember(String(st.get("cue", "skill_area")) + "_stamp")
	_kill_area_tween(st)
	_area_stamp_step(0.0, st)   # 이 틱에 바로 — 트윈의 첫 걸음은 다음 프레임이다
	var total := float(st.hold) + float(st.fade)
	var tw := (n as Node).create_tween()
	tw.tween_method(_area_stamp_step.bind(st), 0.0, total, total)
	tw.tween_callback(_area_done.bind(n))
	st["tween"] = tw


## 칼이 안 닿았다(쓰러짐) — 도장 없이 예고만 AREA_CANCEL초에 걷는다. 도장이 곧 「맞았다」라서.
func cancel_area(n) -> void:
	var st := _area_state(n)
	if st.is_empty() or bool(st.stamped) or bool(st.done):
		return
	_kill_area_tween(st)
	_area_fade_out(n, st)


## 판 노드(트리 밖) + 상태 — 짓는 쪽은 VfxMeshes.make_area(#418), 여기는 되넘김(단위 시험·play_area가 이 이름으로 부른다). def = 큐 표 줄(edge·세기·hold·fade).
## 얼룩 씨앗은 여기 이펙트 RNG(게임 RNG와 분리)에서 — 판마다 다르게. 반환 = {node, mat, xform, area, impact, stamped, done, tween, hold, fade}.
func make_area(area: Dictionary, def: Dictionary, color: Color) -> Dictionary:
	return VfxMeshes.make_area(area, def, color, _rng.randf() * 37.0)


## 예고 세기 0..1 — 시전 뒤 t초, 칼이 닿는 시각 impact초. AREA_PREVIEW_IN초에 차오르고, 닿을 때까지 AREA_PREVIEW_FROM → 1 (ease-in).
static func area_preview(t: float, impact: float) -> float:
	if t <= 0.0:
		return 0.0
	var r := clampf(t / maxf(impact, 0.001), 0.0, 1.0)
	return clampf(t / AREA_PREVIEW_IN, 0.0, 1.0) * lerpf(AREA_PREVIEW_FROM, 1.0, r * r)


## 도장 (세기, 마름) — 닿은 뒤 u초. hold초 동안 (1, 0) → fade초에 세기 (1 − k)^1.5 · 마름 k (빨리 걷히고, 먹은 잡음 순서로 빠진다).
static func area_stamp(u: float, hold: float, fade: float) -> Vector2:
	if u < 0.0:
		return Vector2.ZERO
	if u <= hold:
		return Vector2(1.0, 0.0)
	var k := clampf((u - hold) / maxf(fade, 0.001), 0.0, 1.0)
	return Vector2(pow(1.0 - k, 1.5), k)


func _area_state(n) -> Dictionary:
	if not is_instance_valid(n) or not (n is Node3D) or not (n as Node).has_meta(&"area_state"):
		return {}
	return (n as Node).get_meta(&"area_state")


func _kill_area_tween(st: Dictionary) -> void:
	var tw = st.get("tween")
	if tw is Tween and (tw as Tween).is_valid():
		(tw as Tween).kill()
	st["tween"] = null


func _area_preview_step(u: float, st: Dictionary) -> void:
	(st.mat as ShaderMaterial).set_shader_parameter("preview", area_preview(u, float(st.impact)))


func _area_stamp_step(u: float, st: Dictionary) -> void:
	var k := area_stamp(u, float(st.hold), float(st.fade))
	var mat: ShaderMaterial = st.mat
	mat.set_shader_parameter("preview", 0.0)   # 도장이 예고를 덮는다(셰이더는 둘 중 큰 쪽)
	mat.set_shader_parameter("stamp", k.x)
	mat.set_shader_parameter("dry", k.y)


## 예고 트윈의 끝 — 도장이 끝내 안 왔다(층 이동 등).
func _area_expire(n) -> void:
	var st := _area_state(n)
	if st.is_empty() or bool(st.stamped) or bool(st.done):
		return
	_area_fade_out(n, st)


func _area_fade_out(n, st: Dictionary) -> void:
	st["done"] = true
	var mat: ShaderMaterial = st.mat
	var from := float(mat.get_shader_parameter("preview"))
	var tw := (n as Node).create_tween()
	tw.tween_method(func(v: float) -> void: mat.set_shader_parameter("preview", v), from, 0.0, AREA_CANCEL)
	tw.tween_callback(_area_done.bind(n))
	st["tween"] = tw


func _area_done(n) -> void:
	if not is_instance_valid(n):
		return
	_live_nodes.erase(n)
	(n as Node).queue_free()


# ---------- 내부: 옅은 금빛 (aura, #280) ----------

## 발에서 위로 옅어지는 가산 판(카메라를 본다) — 시안 aura: 가로 (1−|x|)^1.6 × 세로(아래가 짙음)^0.7, 0.25초에 차고 수명의 57%부터 걷힌다.
func _spawn_aura(parent: Node, pos: Vector3, color: Color, scale: float, life: float) -> bool:
	_prune()
	if _live_nodes.size() >= MAX_LIVE or parent == null:
		return false
	var mi := VfxMeshes.aura(color, scale)
	var quad := mi.mesh as QuadMesh
	var mat := mi.material_override as ShaderMaterial
	parent.add_child(mi, true)
	var b := _camera_basis()
	# 판 아래 끝 = 발 (카메라 위 방향으로 반 높이) · 카메라 쪽으로 당겨 몸에 안 가린다(직교라 화면 자리는 그대로)
	mi.global_transform = Transform3D(b, pos + b.y * (quad.size.y * 0.5) + b.z * AURA_FRONT)
	_live_nodes.append(mi)
	var set_k := func(v: float) -> void: mat.set_shader_parameter("strength", v * AURA_STRENGTH)
	var tw := mi.create_tween()
	tw.tween_method(set_k, 0.0, 1.0, 0.25).set_trans(Tween.TRANS_SINE)
	tw.tween_interval(maxf(0.0, life * 0.57 - 0.25))
	tw.tween_method(set_k, 1.0, 0.0, life * 0.43).set_trans(Tween.TRANS_SINE)
	tw.tween_callback(func() -> void:
		if is_instance_valid(mi):
			_live_nodes.erase(mi)
			mi.queue_free())
	return true


# ---------- 내부 ----------

func _root() -> Node:
	var lvl := get_tree().get_first_node_in_group("level")
	return lvl if lvl else get_tree().current_scene


func _remember(tag: String) -> void:
	history.append(tag)
	seq += 1
	if history.size() > HISTORY_MAX:
		history.pop_front()


## 오토로드 이름(DevMode)을 직접 쓰지 않는다 — 단위 테스트(-s, 오토로드 없음)에서도 이 스크립트가 컴파일되게 (memory: --script 오토로드 미로드).
func _log_missing(cue: String) -> void:
	if _missing_logged.has(cue) or not is_inside_tree():
		return
	var dev: Node = get_tree().root.get_node_or_null("DevMode")
	if dev and bool(dev.get("is_active")):
		_missing_logged[cue] = true
		print("[Vfx] missing cue: %s (큐 표 design/vfx.md §2)" % cue)
