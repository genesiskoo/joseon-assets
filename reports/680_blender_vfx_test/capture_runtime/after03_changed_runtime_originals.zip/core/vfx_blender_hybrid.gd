extends Node3D
## #680: Blender procedural-volume atlas + exported mesh GPU particles + manual entrance animation.
## The projectile still owns its opaque body, movement and hit. This replaces only its capped trail.
## Textures/mesh/shader are shared; frame, material, particle seed and AnimationPlayer are actor-local.

const SCRIPT_PATH := "res://core/vfx_blender_hybrid.gd"
const ASSET_DIR := "res://assets/vfx/"
const MAX_PASSES := 5
const MAX_PARTICLES := 12
const GPU_SEED := 680031
const MAX_ALPHA_GAIN := 4.0
const ALPHA_GAINS := {&"fire": [3.2, 3.6, 4.0], &"sal": [2.5, 2.8, 3.2]}
const SIZES := {
	&"fire": [Vector2(0.66, 0.38), Vector2(0.88, 0.55), Vector2(1.12, 0.72)],
	&"sal": [Vector2(0.88, 0.85), Vector2(1.18, 1.10), Vector2(1.50, 1.40)]
}
const BODY_TINT := {&"fire": Color(0.12, 0.018, 0.025), &"sal": Color(0.105, 0.022, 0.105)}
const CORE_TINT := {&"fire": Color(1.0, 0.76, 0.28), &"sal": Color(0.72, 0.22, 0.54)}
static var _assets: Dictionary = {}
static var _shaders: Dictionary = {}

var elapsed := 0.0
var reveal := 0.04
var _frame := 0
var _flight_dir := Vector3.FORWARD
var _screen_angle := 0.0
var _spec: Dictionary = {}
var _meta: Dictionary = {}
var _sheets: Array[MeshInstance3D] = []
var _materials: Array[ShaderMaterial] = []
var _gpu: GPUParticles3D
var _animation: AnimationPlayer


static func make_trail(element: StringName, grade: int, asset_dir: String = ASSET_DIR) -> Node3D:
	if element not in [&"fire", &"sal"] or RenderingServer.get_current_rendering_method() == "gl_compatibility":
		return null
	var bundle := _load_assets(element, asset_dir)
	if bundle.is_empty():
		return null
	var fx = (load(SCRIPT_PATH) as GDScript).new()
	fx._build(element, clampi(grade, 0, 2), bundle)
	if fx.actual_bound_radius() > float(fx._spec.bound_radius) + 0.0001:
		fx.free()
		return null
	return fx


## Cache successes only: a missing optional atlas must remain retryable after intake/import.
static func _load_assets(element: StringName, asset_dir: String) -> Dictionary:
	var stem := "blender_fire_jet" if element == &"fire" else "blender_sal_mist"
	var base := asset_dir.path_join(stem).path_join(stem)
	var key := base
	if _assets.has(key):
		return _assets[key]
	var png := base + "_sheet.png"
	var meta_path := base + "_meta.json"
	var mesh_path := asset_dir.path_join("blender_hybrid").path_join("ember.glb" if element == &"fire" else "drop.glb")
	if not FileAccess.file_exists(meta_path) or not ResourceLoader.exists(png) or not ResourceLoader.exists(mesh_path):
		return {}
	var parsed: Variant = JSON.parse_string(FileAccess.get_file_as_string(meta_path))
	if not parsed is Dictionary or not _valid_meta(parsed):
		return {}
	var texture := load(png) as Texture2D
	if texture == null or texture.get_width() != int(parsed.cols) * int(parsed.fw) or texture.get_height() != int(parsed.rows) * int(parsed.fh):
		return {}
	var scene := load(mesh_path) as PackedScene
	if scene == null:
		return {}
	var instance := scene.instantiate()
	var imported := _first_mesh(instance)
	if imported == null or imported.mesh == null or imported.mesh.get_surface_count() != 1:
		instance.free()
		return {}
	var mesh: Mesh = imported.mesh
	var source_box: AABB = mesh.get_aabb()
	var source_bound := 0.0
	for i in 8:
		source_bound = maxf(source_bound, source_box.get_endpoint(i).length())
	instance.free()
	if not is_finite(source_bound) or source_bound < 0.00001:
		return {}
	var result := {"texture": texture, "meta": parsed.duplicate(true), "mesh": mesh,
		"mesh_scale": 0.055 / source_bound, "mesh_path": mesh_path, "texture_path": png}
	_assets[key] = result
	return result


static func _valid_meta(meta: Dictionary) -> bool:
	for key in ["cols", "rows", "fw", "fh", "total", "fps", "anchor", "loop"]:
		if not meta.has(key):
			return false
	for key in ["cols", "rows", "fw", "fh", "total"]:
		if not (meta[key] is int or meta[key] is float) or not is_finite(float(meta[key])) or float(meta[key]) < 1.0 or float(meta[key]) != float(int(meta[key])):
			return false
	if int(meta.cols) > 16 or int(meta.rows) > 16 or int(meta.total) > int(meta.cols) * int(meta.rows):
		return false
	if not (meta.fps is int or meta.fps is float) or not is_finite(float(meta.fps)) or float(meta.fps) <= 0.0 or float(meta.fps) > 120.0 or meta.loop != true:
		return false
	if not meta.anchor is Array or meta.anchor.size() != 2:
		return false
	for v in meta.anchor:
		if not (v is int or v is float) or not is_finite(float(v)) or float(v) < 0.0 or float(v) > 1.0:
			return false
	return true


static func _first_mesh(node: Node) -> MeshInstance3D:
	if node is MeshInstance3D:
		return node
	for child in node.get_children():
		var found := _first_mesh(child)
		if found != null:
			return found
	return null


func _build(element: StringName, grade: int, bundle: Dictionary) -> void:
	name = "VfxBlender_%s" % element
	process_mode = Node.PROCESS_MODE_PAUSABLE
	_meta = bundle.meta.duplicate(true)
	var radius := 0.30 + float(grade) * 0.10
	var count := int([4, 8, 12][grade])
	_spec = {"element": element, "type": "trail", "grade": grade, "radius": radius,
		"height": SIZES[element][grade].y, "layers": 1, "particles": count,
		"primary_particles": count, "secondary_particles": 0, "draw_passes": 3 if element == &"fire" else 2,
		"duration": 0.0, "body_duration": 0.65, "loop": true,
		"shape": "rocket" if element == &"fire" else "mist", "bound_radius": radius * 2.4,
		"texture_path": bundle.texture_path, "mesh_path": bundle.mesh_path, "gpu_seed": GPU_SEED + grade + (100 if element == &"sal" else 0)}
	_spec["alpha_gain"] = float(ALPHA_GAINS[element][grade])
	set_meta("element_spec", _spec.duplicate(true))
	set_meta("hybrid_spec", _spec.duplicate(true))
	var anchor := Vector2(float(_meta.anchor[0]), float(_meta.anchor[1]))
	var size: Vector2 = SIZES[element][grade]
	var sheet := _make_sheet("VolumeSheet", size, anchor, bundle.texture, element, grade, false)
	if element == &"fire":
		var core := _atlas_material(bundle.texture, element, grade, true)
		core.render_priority = 1
		(sheet.material_override as ShaderMaterial).next_pass = core
		_materials.append(core)
	_gpu = _make_particles(bundle.mesh, float(bundle.mesh_scale), element, grade, count)
	add_child(_gpu)
	_animation = _make_animation()
	add_child(_animation)
	_update_visuals()


func _make_sheet(label: String, size: Vector2, anchor: Vector2, texture: Texture2D, element: StringName, grade: int, core: bool) -> MeshInstance3D:
	var left := -anchor.x * size.x
	var right := (1.0 - anchor.x) * size.x
	var top := anchor.y * size.y
	var bottom := -(1.0 - anchor.y) * size.y
	var arrays := []
	arrays.resize(Mesh.ARRAY_MAX)
	arrays[Mesh.ARRAY_VERTEX] = PackedVector3Array([Vector3(left, bottom, 0), Vector3(right, bottom, 0), Vector3(right, top, 0), Vector3(left, top, 0)])
	arrays[Mesh.ARRAY_TEX_UV] = PackedVector2Array([Vector2(0, 1), Vector2(1, 1), Vector2(1, 0), Vector2(0, 0)])
	arrays[Mesh.ARRAY_INDEX] = PackedInt32Array([0, 1, 2, 0, 2, 3])
	var mesh := ArrayMesh.new()
	mesh.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, arrays)
	var sheet := MeshInstance3D.new()
	sheet.name = label
	sheet.mesh = mesh
	sheet.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	sheet.material_override = _atlas_material(texture, element, grade, core)
	add_child(sheet)
	_sheets.append(sheet)
	_materials.append(sheet.material_override)
	return sheet


func _atlas_material(texture: Texture2D, element: StringName, grade: int, core: bool) -> ShaderMaterial:
	var key := "core" if core else "body"
	if not _shaders.has(key):
		var shader := Shader.new()
		shader.code = ATLAS_SHADER.replace("PASS_BLEND", "blend_add, fog_disabled" if core else "blend_mix").replace("IS_CORE", "true" if core else "false")
		_shaders[key] = shader
	var mat := ShaderMaterial.new()
	mat.shader = _shaders[key]
	mat.set_shader_parameter("atlas", texture)
	mat.set_shader_parameter("grid", Vector2(float(_meta.cols), float(_meta.rows)))
	mat.set_shader_parameter("frame_px", Vector2(float(_meta.fw), float(_meta.fh)))
	mat.set_shader_parameter("frame", 0.0)
	mat.set_shader_parameter("reveal", reveal)
	mat.set_shader_parameter("alpha_gain", clampf(float(ALPHA_GAINS[element][grade]), 0.0, MAX_ALPHA_GAIN))
	mat.set_shader_parameter("body_tint", BODY_TINT[element])
	mat.set_shader_parameter("fire_body", element == &"fire" and not core)
	mat.set_shader_parameter("body_alpha_exponent", 0.62 if element == &"fire" and not core else 1.0)
	mat.set_shader_parameter("core_tint", Color(1.0, 0.38, 0.08) if element == &"fire" else CORE_TINT[element])
	mat.set_shader_parameter("warm_red", Color(0.65, 0.035, 0.004))
	mat.set_shader_parameter("warm_orange", Color(1.0, 0.33, 0.025))
	mat.set_shader_parameter("opacity", (0.38 + float(grade) * 0.07) if core else (0.68 + float(grade) * 0.09))
	mat.set_shader_parameter("energy", 2.0 + float(grade) * 0.35 if core else 1.0)
	return mat


func _make_particles(mesh: Mesh, mesh_scale: float, element: StringName, grade: int, count: int) -> GPUParticles3D:
	var gpu := GPUParticles3D.new()
	gpu.name = "BlenderEmbers" if element == &"fire" else "BlenderDrops"
	gpu.process_mode = Node.PROCESS_MODE_PAUSABLE
	gpu.amount = count
	gpu.lifetime = 0.34 + float(grade) * 0.08 if element == &"fire" else 0.48 + float(grade) * 0.08
	gpu.local_coords = true
	gpu.fixed_fps = 60
	gpu.fract_delta = true
	gpu.use_fixed_seed = true
	gpu.seed = int(_spec.gpu_seed)
	gpu.preprocess = 0.0
	gpu.explosiveness = 0.0
	gpu.randomness = 0.15
	gpu.draw_passes = 1
	gpu.draw_pass_1 = mesh
	gpu.visibility_aabb = AABB(Vector3.ONE * -float(_spec.bound_radius), Vector3.ONE * float(_spec.bound_radius) * 2.0)
	gpu.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	var process := ParticleProcessMaterial.new()
	process.emission_shape = ParticleProcessMaterial.EMISSION_SHAPE_SPHERE
	process.emission_sphere_radius = 0.065 + float(grade) * 0.012
	process.direction = Vector3.BACK
	process.spread = 24.0 if element == &"fire" else 44.0
	process.gravity = Vector3(0, 0.15, 0) if element == &"fire" else Vector3(0, -0.18, 0)
	process.initial_velocity_min = 0.18 if element == &"fire" else 0.12
	process.initial_velocity_max = 0.65 if element == &"fire" else 0.35
	process.scale_min = mesh_scale * (0.45 + float(grade) * 0.10)
	process.scale_max = mesh_scale
	var size_curve := Curve.new()
	size_curve.add_point(Vector2(0, 0.15))
	size_curve.add_point(Vector2(0.18, 1.0))
	size_curve.add_point(Vector2(1, 0.0))
	var size_texture := CurveTexture.new()
	size_texture.curve = size_curve
	process.scale_curve = size_texture
	var color := Gradient.new()
	color.set_color(0, CORE_TINT[element])
	color.set_color(1, Color(CORE_TINT[element], 0.0))
	var ramp := GradientTexture1D.new()
	ramp.gradient = color
	process.color_ramp = ramp
	gpu.process_material = process
	var material := StandardMaterial3D.new()
	material.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	material.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	material.vertex_color_use_as_albedo = true
	material.cull_mode = BaseMaterial3D.CULL_DISABLED
	material.emission_enabled = element == &"fire"
	material.emission = CORE_TINT[element]
	material.emission_energy_multiplier = 1.2 + float(grade) * 0.3
	if element == &"fire":
		material.blend_mode = BaseMaterial3D.BLEND_MODE_ADD
		material.disable_fog = true
	gpu.material_override = material
	return gpu


func _make_animation() -> AnimationPlayer:
	var player := AnimationPlayer.new()
	player.name = "EntranceAnimation"
	player.process_mode = Node.PROCESS_MODE_PAUSABLE
	player.callback_mode_process = AnimationMixer.ANIMATION_CALLBACK_MODE_PROCESS_MANUAL
	var library := AnimationLibrary.new()
	var clip := Animation.new()
	clip.length = 0.12
	var track := clip.add_track(Animation.TYPE_VALUE)
	clip.track_set_path(track, NodePath(".:reveal"))
	clip.track_insert_key(track, 0.0, 0.04)
	clip.track_insert_key(track, 0.035, 0.62)
	clip.track_insert_key(track, 0.12, 1.0)
	library.add_animation(&"appear", clip)
	player.add_animation_library(&"", library)
	return player


func _ready() -> void:
	_animation.play(&"appear")
	_animation.advance(0.0)
	_face_velocity()
	_update_visuals()


func _process(delta: float) -> void:
	if not is_finite(delta) or delta <= 0.0 or (is_inside_tree() and get_tree().paused):
		return
	elapsed += delta
	_animation.advance(delta)
	_face_velocity()
	_update_visuals()


func _notification(what: int) -> void:
	if _gpu == null:
		return
	if what == NOTIFICATION_PAUSED:
		_gpu.speed_scale = 0.0
	elif what == NOTIFICATION_UNPAUSED:
		_gpu.speed_scale = 1.0


func _face_velocity() -> void:
	if not is_inside_tree():
		return
	var carrier := get_parent() as Node3D
	if carrier != null:
		var value: Variant = carrier.get("velocity")
		if value is Vector3 and value.is_finite() and value.length_squared() > 0.000001:
			_flight_dir = value.normalized()
			var up := Vector3.FORWARD if absf(_flight_dir.dot(Vector3.UP)) > 0.98 else Vector3.UP
			global_basis = Basis.looking_at(_flight_dir, up)
	var camera := get_viewport().get_camera_3d()
	if camera == null:
		return
	var camera_basis := camera.global_basis.orthonormalized()
	var projected := Vector2(_flight_dir.dot(camera_basis.x), _flight_dir.dot(camera_basis.y))
	if projected.is_finite() and projected.length_squared() > 0.000001:
		_screen_angle = projected.angle()
	var c := cos(_screen_angle)
	var s := sin(_screen_angle)
	var billboard := Basis(camera_basis.x * c + camera_basis.y * s, -camera_basis.x * s + camera_basis.y * c, camera_basis.z)
	for sheet in _sheets:
		sheet.global_basis = billboard


func _update_visuals() -> void:
	_frame = posmod(int(floor(elapsed * float(_meta.fps))), int(_meta.total))
	for material in _materials:
		material.set_shader_parameter("frame", float(_frame))
		material.set_shader_parameter("reveal", clampf(reveal, 0.0, 1.0))


func snapshot() -> Dictionary:
	var result := _spec.duplicate(true)
	result["elapsed"] = elapsed
	result["frame"] = _frame
	result["reveal"] = reveal
	result["flight_dir"] = _flight_dir
	result["screen_angle"] = _screen_angle
	result["animation_phase"] = _animation.current_animation_position if _animation.is_playing() else 0.12
	result["gpu_speed_scale"] = _gpu.speed_scale
	result["gpu_seed"] = _gpu.seed
	result["particles"] = _gpu.amount
	result["particle_instances"] = _gpu.amount
	result["gpu_local_coords"] = _gpu.local_coords
	result["draw_passes"] = actual_draw_passes()
	result["alpha_gain"] = float(_materials[0].get_shader_parameter("alpha_gain"))
	return result


func actual_draw_passes() -> int:
	var count := 0
	for sheet in _sheets:
		var material: Material = sheet.material_override
		while material != null:
			count += 1
			material = material.next_pass
	return count + _gpu.draw_passes


## Geometry bounds plus the analytic particle travel bound, independent of dummy-renderer feedback.
func actual_bound_radius() -> float:
	var bound := 0.0
	for sheet in _sheets:
		for point in sheet.mesh.surface_get_arrays(0)[Mesh.ARRAY_VERTEX]:
			bound = maxf(bound, point.length())
	var process := _gpu.process_material as ParticleProcessMaterial
	var box := _gpu.draw_pass_1.get_aabb()
	var mesh_bound := 0.0
	for i in 8:
		mesh_bound = maxf(mesh_bound, box.get_endpoint(i).length())
	var particle_bound := process.emission_sphere_radius + process.initial_velocity_max * _gpu.lifetime + process.gravity.length() * _gpu.lifetime * _gpu.lifetime * 0.5 + mesh_bound * process.scale_max
	return maxf(bound, particle_bound)


const ATLAS_SHADER := """shader_type spatial;
render_mode unshaded, cull_disabled, depth_draw_never, PASS_BLEND;
uniform sampler2D atlas : source_color, filter_linear, repeat_disable;
uniform vec2 grid = vec2(6.0, 4.0);
uniform vec2 frame_px = vec2(384.0);
uniform float frame = 0.0;
uniform float reveal = 1.0;
uniform float alpha_gain : hint_range(0.0, 4.0) = 1.0;
uniform vec4 body_tint : source_color;
uniform vec4 core_tint : source_color;
uniform bool fire_body = false;
uniform float body_alpha_exponent : hint_range(0.1, 1.0) = 1.0;
uniform vec4 warm_red : source_color;
uniform vec4 warm_orange : source_color;
uniform float opacity = 0.8;
uniform float energy = 1.0;
void fragment() {
    vec2 cell = vec2(mod(frame, grid.x), floor(frame / grid.x));
    vec2 inset_uv = mix(vec2(0.5) / frame_px, vec2(1.0) - vec2(0.5) / frame_px, UV);
    vec4 texel = texture(atlas, (cell + inset_uv) / grid);
    float density = max(texel.r, max(texel.g, texel.b));
    float volume_alpha = clamp(texel.a * clamp(alpha_gain, 0.0, 4.0), 0.0, 0.95);
    if (IS_CORE) {
        float narrow_core = smoothstep(0.30, 0.80, density);
        float front_taper = smoothstep(0.18, 0.85, UV.x);
        ALBEDO = core_tint.rgb * energy;
        ALPHA = volume_alpha * narrow_core * front_taper * opacity * reveal;
    } else {
        if (fire_body) {
            vec3 warm_color = mix(warm_red.rgb, warm_orange.rgb, smoothstep(0.10, 0.65, density));
            ALBEDO = mix(body_tint.rgb, warm_color, smoothstep(0.015, 0.10, density)) * energy;
            float frayed_alpha = clamp(pow(volume_alpha, body_alpha_exponent), 0.0, 0.95);
            ALPHA = frayed_alpha * opacity * reveal;
        } else {
            ALBEDO = mix(body_tint.rgb, texel.rgb, smoothstep(0.02, 0.18, density)) * energy;
            ALPHA = volume_alpha * opacity * reveal;
        }
    }
}
"""
